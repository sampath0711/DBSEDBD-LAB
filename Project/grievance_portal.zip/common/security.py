"""JWT creation/verification and FastAPI auth dependencies.

Every service verifies the JWT itself with the shared secret (zero-trust inside the
cluster); the gateway does not need to be trusted for authorization decisions.
"""
import hmac
from datetime import timedelta

import jwt
from fastapi import Depends, Header, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from common.config import env, internal_api_key, jwt_secret
from common.schemas import utcnow

ALGORITHM = "HS256"
_bearer = HTTPBearer(auto_error=False)


class CurrentUser(BaseModel):
    id: int
    name: str
    role: str
    department: str | None = None


def create_access_token(user: CurrentUser) -> str:
    minutes = int(env("JWT_EXPIRES_MINUTES", "480"))  # type: ignore[arg-type]
    now = utcnow()
    payload = {
        "sub": str(user.id),
        "name": user.name,
        "role": user.role,
        "department": user.department,
        "iat": now,
        "exp": now + timedelta(minutes=minutes),
    }
    return jwt.encode(payload, jwt_secret(), algorithm=ALGORITHM)


def decode_access_token(token: str) -> CurrentUser:
    payload = jwt.decode(token, jwt_secret(), algorithms=[ALGORITHM])
    return CurrentUser(
        id=int(payload["sub"]),
        name=payload["name"],
        role=payload["role"],
        department=payload.get("department"),
    )


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> CurrentUser:
    if credentials is None:
        raise HTTPException(401, "Missing or invalid Authorization header.")
    try:
        return decode_access_token(credentials.credentials)
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(401, "Invalid or expired token.")


def require_roles(*roles: str):
    async def checker(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in roles:
            raise HTTPException(403, "You do not have permission to perform this action.")
        return user

    return checker


async def require_internal_key(x_internal_key: str | None = Header(default=None)) -> None:
    """Guards service-to-service endpoints. These are never routed by the gateway."""
    if not x_internal_key or not hmac.compare_digest(x_internal_key, internal_api_key()):
        raise HTTPException(403, "Internal endpoint.")
