import os


def env(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    return value if value not in (None, "") else default


def env_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def jwt_secret() -> str:
    return env("JWT_SECRET", "dev-secret-change-me")  # type: ignore[return-value]


def internal_api_key() -> str:
    return env("INTERNAL_API_KEY", "dev-internal-key")  # type: ignore[return-value]
