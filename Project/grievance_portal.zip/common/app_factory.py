import logging
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from common.config import env
from common.errors import register_error_handlers

logging.basicConfig(level=env("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s %(message)s")


def create_app(title: str, description: str, lifespan=None) -> FastAPI:
    app = FastAPI(title=title, description=description, version="1.0.0", lifespan=lifespan)
    origins = [o.strip() for o in (env("CORS_ORIGINS", "*") or "*").split(",")]
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"])
    register_error_handlers(app)

    @app.middleware("http")
    async def request_id(request: Request, call_next):
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
        request.state.request_id = rid
        response = await call_next(request)
        response.headers["X-Request-ID"] = rid
        return response

    @app.get("/health", tags=["ops"])
    async def health():
        return {"status": "ok", "service": title}

    return app
