"""Event bus abstraction: Apache Kafka in Docker, an in-process bus for dev/tests.

Envelope:  {"event_id", "type", "occurred_at", "data": {...}}
Delivery is at-least-once, so consumers must be idempotent (see notification service).
"""
import asyncio
import json
import logging
import uuid
from collections import defaultdict
from typing import Awaitable, Callable

from common.config import env
from common.schemas import utcnow

log = logging.getLogger("events")
Handler = Callable[[dict], Awaitable[None]]

GRIEVANCE_TOPIC = "grievance.events"
AUTH_TOPIC = "auth.events"
DOUBT_TOPIC = "doubt.events"


def make_event(event_type: str, data: dict) -> dict:
    return {
        "event_id": str(uuid.uuid4()),
        "type": event_type,
        "occurred_at": utcnow().isoformat(),
        "data": data,
    }


class EventBus:
    def __init__(self) -> None:
        self._subs: list[tuple[str, str, Handler]] = []

    def subscribe(self, topic: str, group_id: str, handler: Handler) -> None:
        self._subs.append((topic, group_id, handler))

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def publish(self, topic: str, event_type: str, data: dict) -> None: ...


class MemoryBus(EventBus):
    """Synchronous in-process delivery. Handlers are shared across instances so that
    services running in one process (dev server / tests) can talk to each other."""

    _handlers: dict[str, list[Handler]] = defaultdict(list)
    _registered: set[tuple[str, str]] = set()

    async def start(self) -> None:
        for topic, group, handler in self._subs:
            if (topic, group) not in MemoryBus._registered:
                MemoryBus._registered.add((topic, group))
                MemoryBus._handlers[topic].append(handler)

    async def publish(self, topic: str, event_type: str, data: dict) -> None:
        event = make_event(event_type, data)
        for handler in list(MemoryBus._handlers[topic]):
            try:
                await handler(event)
            except Exception:  # noqa: BLE001
                log.exception("Handler failed for %s", event_type)


class KafkaBus(EventBus):
    def __init__(self, servers: str) -> None:
        super().__init__()
        self.servers = servers
        self._producer = None
        self._ready = asyncio.Event()
        self._tasks: list[asyncio.Task] = []

    async def start(self) -> None:
        self._tasks.append(asyncio.create_task(self._connect_producer()))
        for topic, group, handler in self._subs:
            self._tasks.append(asyncio.create_task(self._consume(topic, group, handler)))

    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        if self._producer:
            await self._producer.stop()

    async def _connect_producer(self) -> None:
        from aiokafka import AIOKafkaProducer

        while True:
            try:
                producer = AIOKafkaProducer(bootstrap_servers=self.servers)
                await producer.start()
                self._producer = producer
                self._ready.set()
                log.info("Kafka producer connected to %s", self.servers)
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("Kafka producer not ready (%s); retrying in 3s", exc)
                await asyncio.sleep(3)

    async def publish(self, topic: str, event_type: str, data: dict) -> None:
        event = make_event(event_type, data)
        try:
            await asyncio.wait_for(self._ready.wait(), timeout=5)
            await self._producer.send_and_wait(topic, json.dumps(event).encode(), key=str(data.get("id", "")).encode())
        except Exception:  # noqa: BLE001
            # A broker outage must not fail the user's request. (Production hardening: transactional outbox.)
            log.exception("Could not publish %s to Kafka; event dropped", event_type)

    async def _consume(self, topic: str, group: str, handler: Handler) -> None:
        from aiokafka import AIOKafkaConsumer

        while True:
            consumer = AIOKafkaConsumer(
                topic, bootstrap_servers=self.servers, group_id=group,
                auto_offset_reset="earliest", enable_auto_commit=True,
            )
            try:
                await consumer.start()
                log.info("Kafka consumer %s subscribed to %s", group, topic)
                async for msg in consumer:
                    try:
                        await handler(json.loads(msg.value))
                    except Exception:  # noqa: BLE001
                        log.exception("Failed processing message from %s", topic)
            except asyncio.CancelledError:
                await consumer.stop()
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("Kafka consumer %s not ready (%s); retrying in 3s", group, exc)
                await asyncio.sleep(3)
            finally:
                try:
                    await consumer.stop()
                except Exception:  # noqa: BLE001
                    pass


def get_bus() -> EventBus:
    servers = env("KAFKA_BOOTSTRAP_SERVERS")
    return KafkaBus(servers) if servers else MemoryBus()
