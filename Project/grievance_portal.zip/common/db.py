import asyncio
import logging
import os

from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker, create_async_engine

log = logging.getLogger("db")


def make_engine(url: str) -> AsyncEngine:
    if url.startswith("sqlite") and ":///" in url:
        path = url.split(":///", 1)[1]
        if os.path.dirname(path):
            os.makedirs(os.path.dirname(path), exist_ok=True)
        return create_async_engine(url)
    return create_async_engine(url, pool_pre_ping=True)


def make_session_factory(engine: AsyncEngine):
    return async_sessionmaker(engine, expire_on_commit=False)


async def create_tables(engine: AsyncEngine, metadata, retries: int = 30, delay: float = 2.0) -> None:
    """Create tables, waiting for the database to come up (containers start in any order).
    For a production system replace with Alembic migrations."""
    for attempt in range(1, retries + 1):
        try:
            async with engine.begin() as conn:
                await conn.run_sync(metadata.create_all)
            return
        except Exception as exc:  # noqa: BLE001
            if attempt == retries:
                raise
            log.warning("Database not ready (%s). Retry %d/%d", exc.__class__.__name__, attempt, retries)
            await asyncio.sleep(delay)
