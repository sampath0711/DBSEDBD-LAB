"""HTTP client factory for service-to-service calls.

In Docker the services talk over the network. In the single-process dev server and the
tests, `register_transport` maps a base URL to an in-process ASGI app instead.
"""
import httpx

_TRANSPORTS: dict[str, httpx.AsyncBaseTransport] = {}


def register_transport(base_url: str, transport: httpx.AsyncBaseTransport) -> None:
    _TRANSPORTS[base_url] = transport


def new_client(base_url: str, timeout: float = 10.0) -> httpx.AsyncClient:
    return httpx.AsyncClient(base_url=base_url, timeout=timeout, transport=_TRANSPORTS.get(base_url))
