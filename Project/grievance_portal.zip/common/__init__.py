"""Shared building blocks used by every microservice (security, events, DB helpers)."""
