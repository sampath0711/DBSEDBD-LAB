from common.config import env

_clients: dict = {}


def get_mongo_db(db_name: str):
    """MongoDB database handle. `MONGO_URI=mongomock://...` swaps in an in-memory fake
    (used by the single-process dev server and the test-suite)."""
    uri = env("MONGO_URI", "mongodb://localhost:27017")
    if uri not in _clients:
        if uri.startswith("mongomock"):
            from mongomock_motor import AsyncMongoMockClient

            _clients[uri] = AsyncMongoMockClient()
        else:
            from motor.motor_asyncio import AsyncIOMotorClient

            _clients[uri] = AsyncIOMotorClient(uri, serverSelectionTimeoutMS=5000)
    return _clients[uri][db_name]
