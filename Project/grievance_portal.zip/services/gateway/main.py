"""API gateway: single public entry point. Routes /api/* to the right microservice,
serves the frontend, throttles login attempts and reports aggregate health.
Internal (/internal/*) endpoints of the services are intentionally NOT routable from here."""
import asyncio
import logging
import pathlib
from contextlib import asynccontextmanager

import httpx
from fastapi import Request
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from common.app_factory import create_app
from common.config import env
from common.http import new_client
from services.gateway.ratelimit import SlidingWindowLimiter

log = logging.getLogger("gateway")

SERVICES = {
    "auth": ("AUTH_SERVICE_URL", "http://localhost:8001"),
    "grievance": ("GRIEVANCE_SERVICE_URL", "http://localhost:8002"),
    "notification": ("NOTIFICATION_SERVICE_URL", "http://localhost:8003"),
    "admin": ("ADMIN_SERVICE_URL", "http://localhost:8004"),
    "doubt": ("DOUBT_SERVICE_URL", "http://localhost:8005"),
}
# public prefix (first path segment after /api) -> (service, upstream path prefix)
ROUTES = {
    "auth": ("auth", "/auth"),
    "grievances": ("grievance", "/grievances"),
    "categories": ("admin", "/categories"),
    "admin": ("admin", "/admin"),
    "notifications": ("notification", "/notifications"),
    "doubts": ("doubt", "/doubts"),
}
HOP_BY_HOP = {"host", "content-length", "connection", "keep-alive", "transfer-encoding", "upgrade", "te", "trailer"}
RESPONSE_SKIP = HOP_BY_HOP | {"content-encoding"}

limiter = SlidingWindowLimiter(int(env("LOGIN_RATE_LIMIT_PER_MIN", "30")))  # type: ignore[arg-type]


@asynccontextmanager
async def lifespan(app):
    app.state.clients = {name: new_client(env(var, default)) for name, (var, default) in SERVICES.items()}  # type: ignore[arg-type]
    yield
    await asyncio.gather(*(c.aclose() for c in app.state.clients.values()))


app = create_app("API Gateway", "Public entry point for the Grievance Redressal Portal microservices.", lifespan)


@app.get("/api/health", tags=["ops"])
async def aggregate_health(request: Request):
    async def probe(name: str, client: httpx.AsyncClient):
        try:
            r = await client.get("/health", timeout=3)
            return name, "ok" if r.status_code == 200 else f"error {r.status_code}"
        except Exception:  # noqa: BLE001
            return name, "unreachable"

    results = dict(await asyncio.gather(*(probe(n, c) for n, c in request.app.state.clients.items())))
    healthy = all(v == "ok" for v in results.values())
    return JSONResponse(
        {"status": "ok" if healthy else "degraded", "gateway": "ok", "services": results},
        status_code=200 if healthy else 503,
    )


@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
async def proxy(path: str, request: Request):
    first, _, rest = path.partition("/")
    if first not in ROUTES:
        return JSONResponse({"error": "Not found."}, status_code=404)
    service, upstream_prefix = ROUTES[first]

    if first == "auth" and rest == "login":
        client_ip = request.client.host if request.client else "unknown"
        if not limiter.allow(client_ip):
            return JSONResponse({"error": "Too many login attempts. Please wait a minute."}, status_code=429)

    upstream_path = upstream_prefix + (f"/{rest}" if rest else "")
    if request.url.query:                      # forward the raw query string so repeated params survive
        upstream_path += f"?{request.url.query}"
    headers = {k: v for k, v in request.headers.items() if k.lower() not in HOP_BY_HOP}
    headers["X-Request-ID"] = request.state.request_id
    headers["X-Forwarded-For"] = request.client.host if request.client else ""

    client: httpx.AsyncClient = request.app.state.clients[service]
    try:
        upstream = await client.request(
            request.method, upstream_path, content=await request.body(), headers=headers,
        )
    except httpx.TimeoutException:
        return JSONResponse({"error": f"The {service} service timed out."}, status_code=504)
    except httpx.TransportError:
        log.error("upstream %s unreachable", service)
        return JSONResponse({"error": f"The {service} service is unavailable. Please try again shortly."}, status_code=503)

    out_headers = {k: v for k, v in upstream.headers.items() if k.lower() not in RESPONSE_SKIP}
    return Response(content=upstream.content, status_code=upstream.status_code, headers=out_headers)


# Frontend (registered last so /api/* and /health win)
_frontend = pathlib.Path(env("FRONTEND_DIR", str(pathlib.Path(__file__).resolve().parents[2] / "frontend")))  # type: ignore[arg-type]
if _frontend.exists():
    app.mount("/", StaticFiles(directory=_frontend, html=True), name="frontend")
