from sqlalchemy.orm import DeclarativeBase

from common.config import env
from common.db import make_engine, make_session_factory
from common.mongo import get_mongo_db

engine = make_engine(env("GRIEVANCE_DATABASE_URL", "sqlite+aiosqlite:///./.data/grievance.db"))
SessionLocal = make_session_factory(engine)
MONGO_DB_NAME = env("GRIEVANCE_MONGO_DB", "grievance_docs")


class Base(DeclarativeBase):
    pass


async def get_session():
    async with SessionLocal() as session:
        yield session


def mongo():
    return get_mongo_db(MONGO_DB_NAME)
