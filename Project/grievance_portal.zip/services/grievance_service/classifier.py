"""Rule-based triage: suggests a category and priority from the complaint text.

Deliberately simple and explainable (keyword evidence is returned to the caller).
The `classify` signature is the seam where an ML model / LLM call can replace it later.
"""
import re
from dataclasses import dataclass, field

CATEGORY_KEYWORDS: dict[str, set[str]] = {
    "Academic": {"course", "class", "lecture", "faculty", "professor", "elective", "syllabus", "timetable",
                 "attendance", "curriculum", "assignment", "lab", "teaching", "section"},
    "Examination": {"exam", "grade", "grades", "marks", "result", "results", "revaluation", "hall", "ticket",
                    "invigilator", "paper", "backlog", "transcript", "cgpa", "scorecard"},
    "Infrastructure": {"projector", "wifi", "internet", "classroom", "building", "electricity", "power", "ac",
                       "fan", "light", "lift", "elevator", "toilet", "restroom", "repair", "broken", "leak",
                       "leakage", "furniture", "bench", "parking", "road"},
    "Hostel": {"hostel", "mess", "warden", "room", "dorm", "canteen", "food", "laundry", "block", "roommate",
               "curfew"},
    "Administrative": {"fee", "fees", "payment", "refund", "scholarship", "certificate", "bonafide", "id",
                       "payroll", "salary", "deduction", "registrar", "admission", "document", "receipt"},
}
URGENT_WORDS = {"harassment", "ragging", "fire", "shock", "injury", "injured", "unsafe", "safety", "threat",
                "emergency", "assault", "hazard", "danger", "dangerous", "urgent", "medical", "bullying"}
HIGH_WORDS = {"delay", "delayed", "repeated", "repeatedly", "again", "weeks", "deadline", "not working",
              "scholarship", "unresolved", "ignored", "no response", "broken", "duplicate"}


@dataclass
class Classification:
    category: str
    priority: str
    confidence: float
    matched: list[str] = field(default_factory=list)


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z]+", text.lower()))


def classify(text: str, known_categories: list[str] | None = None, fallback: str = "Administrative") -> Classification:
    tokens = _tokens(text)
    lowered = text.lower()
    scores: dict[str, list[str]] = {}
    for category, words in CATEGORY_KEYWORDS.items():
        if known_categories is not None and category not in known_categories:
            continue
        hits = sorted(tokens & words)
        if hits:
            scores[category] = hits

    if scores:
        best = max(scores, key=lambda c: len(scores[c]))
        total_hits = sum(len(v) for v in scores.values())
        confidence = round(len(scores[best]) / total_hits, 2)
        matched = scores[best]
    else:
        best, confidence, matched = fallback, 0.0, []
        if known_categories and best not in known_categories:
            best = known_categories[0]

    if tokens & URGENT_WORDS:
        priority = "Urgent"
    elif tokens & HIGH_WORDS or any(p in lowered for p in HIGH_WORDS if " " in p):
        priority = "High"
    else:
        priority = "Routine"
    return Classification(best, priority, confidence, matched)
