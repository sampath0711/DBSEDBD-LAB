from datetime import datetime

from sqlalchemy import DateTime, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from common.schemas import utcnow
from services.grievance_service.database import Base


class Grievance(Base):
    """Structured, relational part of a case. Free-form parts (timeline, classifier output)
    live in MongoDB, keyed by this row's id."""
    __tablename__ = "grievances"
    __table_args__ = (Index("ix_grievances_dept_status", "department", "status"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    case_code: Mapped[str] = mapped_column(String(20), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(80), index=True)
    priority: Mapped[str] = mapped_column(String(10), default="Routine")
    status: Mapped[str] = mapped_column(String(20), default="Submitted", index=True)
    department: Mapped[str] = mapped_column(String(120))
    submitted_by: Mapped[int] = mapped_column(index=True)            # user id from the auth service
    submitted_by_name: Mapped[str] = mapped_column(String(120))      # denormalised: no cross-service join needed
    assigned_to: Mapped[str | None] = mapped_column(String(120), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
