"""Timeline + per-case classifier metadata stored in MongoDB (flexible, append-only documents)."""
from common.schemas import utcnow
from services.grievance_service.database import mongo


async def ensure_indexes() -> None:
    await mongo()["timeline"].create_index("grievance_id")
    await mongo()["details"].create_index("grievance_id", unique=True)


async def add_event(grievance_id: int, text: str, kind: str = "system", actor: str | None = None, when=None) -> None:
    await mongo()["timeline"].insert_one(
        {"grievance_id": grievance_id, "text": text, "kind": kind, "actor": actor, "created_at": when or utcnow()}
    )


async def timelines_for(ids: list[int]) -> dict[int, list[dict]]:
    result: dict[int, list[dict]] = {i: [] for i in ids}
    if not ids:
        return result
    cursor = mongo()["timeline"].find({"grievance_id": {"$in": ids}}).sort([("created_at", 1), ("_id", 1)])
    async for doc in cursor:
        result[doc["grievance_id"]].append({"when": doc["created_at"], "what": doc["text"]})
    return result


async def save_details(grievance_id: int, details: dict) -> None:
    await mongo()["details"].replace_one({"grievance_id": grievance_id}, {"grievance_id": grievance_id, **details}, upsert=True)


async def details_for(grievance_id: int) -> dict | None:
    return await mongo()["details"].find_one({"grievance_id": grievance_id}, {"_id": 0})
