"""TF-IDF cosine similarity for finding related/duplicate grievances.

Pure Python, no model downloads. Lexical rather than truly semantic ("Wi-Fi down" will not
match "internet outage" unless words overlap); the `rank` function is the seam for swapping
in sentence embeddings + a vector index later.
"""
import math
import re
from collections import Counter

STOPWORDS = set(
    "the a an and or of to in on at for with from by is are was were be been it this that these those i we my our "
    "has have had not no but as so if then there their they them its into than over under about after before "
    "very can could would should will please sir madam".split()
)


def tokenize(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return [w[:-1] if w.endswith("s") and len(w) > 3 else w for w in words if w not in STOPWORDS and len(w) > 2]


def rank(query: str, docs: list[tuple[int, str]], limit: int = 5, min_score: float = 0.08) -> list[tuple[int, float]]:
    """Return [(doc_key, score)] best-first for the documents most similar to `query`."""
    tokenized = [(key, Counter(tokenize(text))) for key, text in docs]
    n = len(tokenized)
    df: Counter = Counter()
    for _, counts in tokenized:
        df.update(counts.keys())

    def vectorize(counts: Counter) -> dict[str, float]:
        return {t: c * (math.log((1 + n) / (1 + df.get(t, 0))) + 1.0) for t, c in counts.items()}

    q_vec = vectorize(Counter(tokenize(query)))
    q_norm = math.sqrt(sum(v * v for v in q_vec.values()))
    if not q_norm:
        return []
    scored = []
    for key, counts in tokenized:
        d_vec = vectorize(counts)
        d_norm = math.sqrt(sum(v * v for v in d_vec.values()))
        if not d_norm:
            continue
        dot = sum(q_vec[t] * d_vec[t] for t in q_vec.keys() & d_vec.keys())
        score = dot / (q_norm * d_norm)
        if score >= min_score:
            scored.append((key, round(score, 3)))
    return sorted(scored, key=lambda kv: kv[1], reverse=True)[:limit]
