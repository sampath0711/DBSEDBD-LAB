from contextlib import asynccontextmanager

from common.app_factory import create_app
from common.config import env_bool
from common.db import create_tables
from common.events import get_bus
from services.grievance_service import routes, timeline
from services.grievance_service.database import Base, engine
from services.grievance_service.seed import seed_demo_grievances


@asynccontextmanager
async def lifespan(app):
    await create_tables(engine, Base.metadata)
    await timeline.ensure_indexes()
    if env_bool("SEED_DEMO_DATA", True):
        await seed_demo_grievances()
    routes.bus = get_bus()
    await routes.bus.start()
    yield
    await routes.bus.stop()
    await engine.dispose()


app = create_app(
    "Grievance Service",
    "Core case management: PostgreSQL for structured data, MongoDB for timelines, Kafka for events.",
    lifespan,
)
app.include_router(routes.router)
app.include_router(routes.internal)
