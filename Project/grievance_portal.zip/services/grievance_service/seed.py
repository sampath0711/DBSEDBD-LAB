from datetime import timedelta

from sqlalchemy import func, select

from common.schemas import utcnow
from services.grievance_service import timeline
from services.grievance_service.database import SessionLocal
from services.grievance_service.models import Grievance

# submitted_by ids refer to the auth service's demo users (created in this exact order):
# 1 Ananya Rao, 2 Karthik Nair, 3 Ramesh Iyer, 4 Priya Menon
ANANYA, KARTHIK, RAMESH, PRIYA = (1, "Ananya Rao"), (2, "Karthik Nair"), (3, "Ramesh Iyer"), (4, "Priya Menon")

SEED = [
    dict(code="GRC-091", title="Mess food quality complaint", category="Hostel", priority="High", status="In Progress",
         by=ANANYA, dept="Hostel Administration", days=6,
         desc="Repeated instances of undercooked food in Block C mess over the past two weeks, with no response from the mess committee.",
         tl=[(6, "Grievance submitted by complainant."),
             (5, "Auto-categorized as Hostel · High priority, routed to Hostel Administration."),
             (3, "Assigned to Hostel Warden for inspection."),
             (1, "Site inspection completed, corrective action in progress.")]),
    dict(code="GRC-095", title="Delay in semester grade upload", category="Examination", priority="Routine", status="Under Review",
         by=ANANYA, dept="Controller of Examinations", days=4,
         desc="Grades for the Database Systems course have not been uploaded three weeks after the exam, delaying scholarship processing.",
         tl=[(4, "Grievance submitted by complainant."),
             (3, "Auto-categorized as Examination · Routine, routed to Controller of Examinations."),
             (1, "Under review by examination cell.")]),
    dict(code="GRC-101", title="Broken projector in Lab 4", category="Infrastructure", priority="Routine", status="Resolved",
         by=RAMESH, dept="Facilities & Maintenance", days=12,
         desc="Ceiling projector in Lab 4 has not powered on for two weeks, affecting scheduled practical sessions.",
         tl=[(12, "Grievance submitted by complainant."), (11, "Routed to Facilities & Maintenance."),
             (9, "Technician dispatched."), (7, "Projector replaced and tested. Marked resolved.")]),
    dict(code="GRC-104", title="Incorrect fee deduction on portal", category="Administrative", priority="Urgent", status="Submitted",
         by=PRIYA, dept="Registrar's Office", days=1,
         desc="Payroll portal shows a duplicate deduction for August salary, causing a mismatch with the payslip.",
         tl=[(1, "Grievance submitted by complainant."),
             (1, "Auto-categorized as Administrative · Urgent, routed to Registrar's Office.")]),
    dict(code="GRC-106", title="Water leakage in hostel corridor", category="Hostel", priority="Urgent", status="Under Review",
         by=KARTHIK, dept="Hostel Administration", days=2,
         desc="Persistent water leakage in the second-floor corridor of Block A, creating a slip hazard near the stairwell.",
         tl=[(2, "Grievance submitted by complainant."),
             (2, "Flagged Urgent by automated triage, routed to Hostel Administration."),
             (1, "Maintenance team notified, inspection scheduled.")]),
    dict(code="GRC-108", title="Elective allotment discrepancy", category="Academic", priority="High", status="Closed",
         by=RAMESH, dept="Academic Affairs Office", days=20,
         desc="Two students were allotted to an elective section that had already reached capacity, exceeding the classroom limit.",
         tl=[(20, "Grievance submitted by complainant."), (19, "Routed to Academic Affairs Office."),
             (16, "Section capacity corrected, students reassigned."), (15, "Confirmed resolved by complainant. Case closed.")]),
]


async def seed_demo_grievances() -> None:
    async with SessionLocal() as session:
        if (await session.execute(select(func.count()).select_from(Grievance))).scalar_one() > 0:
            return
        now = utcnow()
        created = []
        for s in SEED:
            g = Grievance(
                case_code=s["code"], title=s["title"], description=s["desc"], category=s["category"],
                priority=s["priority"], status=s["status"], department=s["dept"],
                submitted_by=s["by"][0], submitted_by_name=s["by"][1], created_at=now - timedelta(days=s["days"]),
                updated_at=now - timedelta(days=s["tl"][-1][0]),
            )
            session.add(g)
            created.append((g, s))
        await session.commit()
    for g, s in created:
        for days_ago, text in s["tl"]:
            await timeline.add_event(g.id, text, when=now - timedelta(days=days_ago))
