from typing import Literal

from pydantic import BaseModel, Field

from common.schemas import ORMModel, UTCDateTime

Status = Literal["Submitted", "Under Review", "In Progress", "Resolved", "Closed"]
Priority = Literal["Routine", "High", "Urgent"]


class GrievanceIn(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(min_length=10, max_length=5000)
    category: str | None = Field(default=None, description="Omit (or send 'Auto') to let the classifier choose.")
    priority: Priority | None = Field(default=None, description="Omit to let the classifier suggest one.")


class GrievanceUpdate(BaseModel):
    status: Status | None = None
    department: str | None = Field(default=None, max_length=120)
    priority: Priority | None = None
    assigned_to: str | None = Field(default=None, max_length=120)
    note: str | None = Field(default=None, max_length=1000)


class CommentIn(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


class TimelineItem(BaseModel):
    when: UTCDateTime
    what: str


class ClassificationOut(BaseModel):
    suggested_category: str
    suggested_priority: Priority
    confidence: float
    matched_keywords: list[str]


class GrievanceOut(ORMModel):
    id: int
    case_code: str
    title: str
    description: str
    category: str
    priority: str
    status: str
    department: str
    submitted_by: int
    submitted_by_name: str
    assigned_to: str | None = None
    created_at: UTCDateTime
    updated_at: UTCDateTime
    timeline: list[TimelineItem] = []
    classification: ClassificationOut | None = None


class SimilarOut(ORMModel):
    id: int
    case_code: str
    title: str
    category: str
    status: str
    department: str
    score: float


class StatsOut(BaseModel):
    total: int
    open: int
    resolved: int
    urgent: int
