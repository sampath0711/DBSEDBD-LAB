import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, or_, select, true
from sqlalchemy.ext.asyncio import AsyncSession

from common.events import GRIEVANCE_TOPIC, EventBus
from common.security import CurrentUser, get_current_user, require_internal_key, require_roles
from services.grievance_service import categories, schemas, timeline
from services.grievance_service.classifier import classify
from services.grievance_service.database import get_session
from services.grievance_service.models import Grievance
from services.grievance_service.similarity import rank

router = APIRouter(prefix="/grievances", tags=["grievances"])
internal = APIRouter(prefix="/internal", tags=["internal"], dependencies=[Depends(require_internal_key)])

bus: EventBus | None = None  # injected by main.py
OPEN_EXCLUDED = ("Resolved", "Closed")


# ---------------------------------------------------------------- helpers
def visible_to(user: CurrentUser):
    """Row-level visibility, enforced in SQL so a user can never even load another user's case."""
    if user.role == "admin":
        return true()
    if user.role == "staff":
        return or_(Grievance.department == user.department, Grievance.submitted_by == user.id)
    return Grievance.submitted_by == user.id


def _can_view(user: CurrentUser, g: Grievance) -> bool:
    return (
        user.role == "admin"
        or g.submitted_by == user.id
        or (user.role == "staff" and g.department == user.department)
    )


async def _load_accessible(session: AsyncSession, grievance_id: int, user: CurrentUser) -> Grievance:
    g = await session.get(Grievance, grievance_id)
    if not g:
        raise HTTPException(404, "Case not found.")
    if not _can_view(user, g):
        raise HTTPException(403, "You do not have access to this case.")
    return g


async def _serialize(grievances: list[Grievance], with_details: bool = False) -> list[schemas.GrievanceOut]:
    timelines = await timeline.timelines_for([g.id for g in grievances])
    out = []
    for g in grievances:
        item = schemas.GrievanceOut.model_validate(g)
        item.timeline = [schemas.TimelineItem(**t) for t in timelines[g.id]]
        if with_details:
            details = await timeline.details_for(g.id)
            if details and details.get("classification"):
                item.classification = schemas.ClassificationOut(**details["classification"])
        out.append(item)
    return out


def _similar(g: Grievance, score: float) -> schemas.SimilarOut:
    return schemas.SimilarOut(
        id=g.id, case_code=g.case_code, title=g.title, category=g.category,
        status=g.status, department=g.department, score=score,
    )


async def _publish(event_type: str, g: Grievance, actor: CurrentUser, **extra) -> None:
    if bus:
        await bus.publish(GRIEVANCE_TOPIC, event_type, {
            "id": g.id, "case_code": g.case_code, "title": g.title, "category": g.category,
            "priority": g.priority, "status": g.status, "department": g.department,
            "submitted_by": g.submitted_by, "actor_id": actor.id, "actor_name": actor.name,
            "actor_role": actor.role, **extra,
        })


# ---------------------------------------------------------------- list / stats / search
@router.get("", response_model=list[schemas.GrievanceOut])
async def list_grievances(
    status: schemas.Status | None = None,
    category: str | None = None,
    priority: schemas.Priority | None = None,
    user: CurrentUser = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    query = select(Grievance).where(visible_to(user)).order_by(Grievance.created_at.desc(), Grievance.id.desc())
    if status:
        query = query.where(Grievance.status == status)
    if category:
        query = query.where(Grievance.category == category)
    if priority:
        query = query.where(Grievance.priority == priority)
    rows = (await session.execute(query)).scalars().all()
    return await _serialize(list(rows))


@router.get("/stats", response_model=schemas.StatsOut)
async def stats(user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(
        select(Grievance.status, Grievance.priority, func.count()).where(visible_to(user))
        .group_by(Grievance.status, Grievance.priority)
    )).all()
    total = sum(c for _, _, c in rows)
    open_ = sum(c for s, _, c in rows if s not in OPEN_EXCLUDED)
    urgent = sum(c for s, p, c in rows if p == "Urgent" and s not in OPEN_EXCLUDED)
    return schemas.StatsOut(total=total, open=open_, resolved=total - open_, urgent=urgent)


@router.get("/search", response_model=list[schemas.SimilarOut])
async def search_similar(
    q: str = Query(min_length=3, max_length=500, description="Describe the problem in your own words"),
    limit: int = Query(5, ge=1, le=20),
    user: CurrentUser = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    """Find existing cases (that you are allowed to see) similar to a free-text description."""
    rows = (await session.execute(
        select(Grievance).where(visible_to(user)).order_by(Grievance.created_at.desc()).limit(500)
    )).scalars().all()
    by_id = {g.id: g for g in rows}
    ranked = rank(q, [(g.id, f"{g.title} {g.title} {g.description}") for g in rows], limit=limit)
    return [_similar(by_id[i], score) for i, score in ranked]


@router.get("/{grievance_id}", response_model=schemas.GrievanceOut)
async def get_grievance(grievance_id: int, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    g = await _load_accessible(session, grievance_id, user)
    return (await _serialize([g], with_details=True))[0]


@router.get("/{grievance_id}/similar", response_model=list[schemas.SimilarOut])
async def similar_cases(grievance_id: int, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    g = await _load_accessible(session, grievance_id, user)
    rows = (await session.execute(
        select(Grievance).where(visible_to(user), Grievance.id != g.id).order_by(Grievance.created_at.desc()).limit(500)
    )).scalars().all()
    by_id = {r.id: r for r in rows}
    ranked = rank(f"{g.title} {g.title} {g.description}", [(r.id, f"{r.title} {r.title} {r.description}") for r in rows], limit=5)
    return [_similar(by_id[i], score) for i, score in ranked]


# ---------------------------------------------------------------- create
@router.post("", response_model=schemas.GrievanceOut, status_code=201)
async def create_grievance(body: schemas.GrievanceIn, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    category_map = await categories.get_category_map()
    result = classify(f"{body.title} {body.description}", list(category_map))

    auto = not body.category or body.category == "Auto"
    category = result.category if auto else body.category
    if category not in category_map:
        raise HTTPException(400, "Unknown category.")
    priority = body.priority or result.priority
    department = category_map[category]

    g = Grievance(
        case_code=f"tmp-{uuid.uuid4().hex[:12]}", title=body.title.strip(), description=body.description.strip(),
        category=category, priority=priority, status="Submitted", department=department,
        submitted_by=user.id, submitted_by_name=user.name,
    )
    session.add(g)
    await session.flush()                      # obtain the id, then derive a unique, race-free case code from it
    g.case_code = f"GRC-{1000 + g.id}"
    await session.commit()

    await timeline.add_event(g.id, "Grievance submitted by complainant.", actor=user.name)
    verb = "Auto-categorized" if auto else "Categorized"
    await timeline.add_event(g.id, f"{verb} as {category} · {priority}, routed to {department}.")
    classification = {
        "suggested_category": result.category, "suggested_priority": result.priority,
        "confidence": result.confidence, "matched_keywords": result.matched,
    }
    await timeline.save_details(g.id, {"classification": classification, "chosen_category": category, "auto_categorized": auto})
    await _publish("grievance.created", g, user)

    out = (await _serialize([g], with_details=True))[0]
    return out


# ---------------------------------------------------------------- update / comment
@router.patch("/{grievance_id}", response_model=schemas.GrievanceOut, dependencies=[Depends(require_roles("admin", "staff"))])
async def update_grievance(
    grievance_id: int, body: schemas.GrievanceUpdate,
    user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session),
):
    g = await session.get(Grievance, grievance_id)
    if not g:
        raise HTTPException(404, "Case not found.")
    if user.role == "staff" and g.department != user.department:
        raise HTTPException(403, "You can only update cases routed to your department.")

    old = {"status": g.status, "department": g.department, "priority": g.priority, "assigned_to": g.assigned_to}
    parts = []
    if body.status and body.status != g.status:
        g.status = body.status
        parts.append(f"Status changed to {body.status}.")
    if body.department and body.department != g.department:
        g.department = body.department
        parts.append(f"Reassigned to {body.department}.")
    if body.priority and body.priority != g.priority:
        g.priority = body.priority
        parts.append(f"Priority changed to {body.priority}.")
    if body.assigned_to and body.assigned_to != g.assigned_to:
        g.assigned_to = body.assigned_to
        parts.append(f"Assigned to {body.assigned_to}.")
    if body.note and body.note.strip():
        parts.append(body.note.strip())
    entry = " ".join(parts) or "Case reviewed, no change."

    await session.commit()
    await timeline.add_event(g.id, entry, kind="update", actor=user.name)
    await _publish(
        "grievance.updated", g, user,
        old_status=old["status"], old_department=old["department"], old_priority=old["priority"],
        changes=[p for p in parts if p != (body.note or "").strip()], note=(body.note or "").strip() or None,
    )
    await session.refresh(g)
    return (await _serialize([g], with_details=True))[0]


@router.post("/{grievance_id}/comments", response_model=schemas.GrievanceOut, status_code=201)
async def add_comment(
    grievance_id: int, body: schemas.CommentIn,
    user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session),
):
    g = await _load_accessible(session, grievance_id, user)
    await timeline.add_event(g.id, f"{user.name} ({user.role}): {body.text.strip()}", kind="comment", actor=user.name)
    await _publish("grievance.commented", g, user, comment=body.text.strip()[:200])
    return (await _serialize([g]))[0]


# ---------------------------------------------------------------- internal (service-to-service)
@internal.get("/stats")
async def internal_stats(session: AsyncSession = Depends(get_session)):
    async def grouped(column):
        rows = (await session.execute(select(column, func.count()).group_by(column))).all()
        return {k: c for k, c in rows}

    by_status = await grouped(Grievance.status)
    total = sum(by_status.values())
    open_ = sum(c for s, c in by_status.items() if s not in OPEN_EXCLUDED)
    urgent_open = (await session.execute(
        select(func.count()).where(Grievance.priority == "Urgent", Grievance.status.notin_(OPEN_EXCLUDED))
    )).scalar_one()
    return {
        "total": total, "open": open_, "resolved": total - open_, "urgent_open": urgent_open,
        "by_status": by_status, "by_category": await grouped(Grievance.category),
        "by_department": await grouped(Grievance.department), "by_priority": await grouped(Grievance.priority),
        "resolution_rate": round((total - open_) / total, 3) if total else 0.0,
    }
