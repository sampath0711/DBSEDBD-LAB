"""Category → department lookup, owned by the Admin service and fetched over REST.

Cached briefly; if the admin service is unreachable we fall back to the last good copy
(or built-in defaults) so grievance submission keeps working during an outage.
"""
import logging
import time

from common.config import env, internal_api_key
from common.http import new_client

log = logging.getLogger("categories")

FALLBACK = {
    "Academic": "Academic Affairs Office",
    "Examination": "Controller of Examinations",
    "Infrastructure": "Facilities & Maintenance",
    "Hostel": "Hostel Administration",
    "Administrative": "Registrar's Office",
}
_cache: dict = {"at": 0.0, "map": None}
TTL_SECONDS = 30


async def get_category_map() -> dict[str, str]:
    now = time.monotonic()
    if _cache["map"] is not None and now - _cache["at"] < TTL_SECONDS:
        return _cache["map"]
    try:
        async with new_client(env("ADMIN_SERVICE_URL", "http://localhost:8004"), timeout=3) as client:  # type: ignore[arg-type]
            response = await client.get("/internal/categories", headers={"X-Internal-Key": internal_api_key()})
            response.raise_for_status()
            mapping = {c["name"]: c["default_department"] for c in response.json()}
        if mapping:
            _cache.update(at=now, map=mapping)
            return mapping
    except Exception as exc:  # noqa: BLE001
        log.warning("Admin service unavailable (%s); using %s categories", exc, "cached" if _cache["map"] else "fallback")
    return _cache["map"] or dict(FALLBACK)


def invalidate_cache() -> None:
    _cache.update(at=0.0, map=None)
