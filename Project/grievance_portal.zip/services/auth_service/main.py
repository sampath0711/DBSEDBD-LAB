from contextlib import asynccontextmanager

from common.app_factory import create_app
from common.config import env_bool
from common.db import create_tables
from common.events import get_bus
from services.auth_service import routes
from services.auth_service.database import Base, engine
from services.auth_service.seed import seed_demo_users


@asynccontextmanager
async def lifespan(app):
    await create_tables(engine, Base.metadata)
    if env_bool("SEED_DEMO_DATA", True):
        await seed_demo_users()
    routes.bus = get_bus()
    await routes.bus.start()
    yield
    await routes.bus.stop()
    await engine.dispose()


app = create_app("Auth Service", "Accounts, login and JWT issuing (PostgreSQL).", lifespan)
app.include_router(routes.router)
app.include_router(routes.internal)
