from sqlalchemy import func, select

from services.auth_service.database import SessionLocal
from services.auth_service.models import User
from services.auth_service.routes import hash_password

DEMO_PASSWORD = "password123"

# ORDER MATTERS: on an empty table these get ids 1..6, which the grievance seed data refers to.
DEMO_USERS = [
    ("Ananya Rao", "ananya.rao@campus.edu", "student", None),
    ("Karthik Nair", "karthik.nair@campus.edu", "student", None),
    ("Ramesh Iyer", "ramesh.iyer@campus.edu", "faculty", "Academic Affairs Office"),
    ("Priya Menon", "priya.menon@campus.edu", "staff", "Registrar's Office"),
    ("Divya Kumar", "divya.kumar@campus.edu", "staff", "Hostel Administration"),
    ("Admin User", "admin@campus.edu", "admin", None),
]


async def seed_demo_users() -> None:
    async with SessionLocal() as session:
        if (await session.execute(select(func.count()).select_from(User))).scalar_one() > 0:
            return
        password_hash = await hash_password(DEMO_PASSWORD)
        for name, email, role, department in DEMO_USERS:
            session.add(User(name=name, email=email, password_hash=password_hash, role=role, department=department))
            await session.flush()  # keep ids deterministic
        await session.commit()
