from typing import Literal

from pydantic import BaseModel, EmailStr, Field, model_validator

from common.schemas import ORMModel, UTCDateTime

Role = Literal["student", "faculty", "staff", "admin"]


class LoginIn(BaseModel):
    email: str
    password: str


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: Literal["student", "faculty"] = "student"  # staff/admin accounts are created by an admin
    department: str | None = Field(default=None, max_length=120, description="Required for faculty; ignored for students.")
    faculty_code: str | None = Field(default=None, max_length=100, description="Institution-issued code, required for faculty.")

    @model_validator(mode="after")
    def faculty_need_department(self):
        if self.role == "faculty" and not (self.department and self.department.strip()):
            raise ValueError("Faculty accounts need a department.")
        return self


class UserCreateIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: Role
    department: str | None = Field(default=None, max_length=120)

    @model_validator(mode="after")
    def staff_need_department(self):
        if self.role == "staff" and not self.department:
            raise ValueError("Staff accounts need a department (used for case routing).")
        return self


class SessionUser(ORMModel):
    """What goes into the JWT and is returned to the frontend after login."""
    id: int
    name: str
    role: str
    department: str | None = None


class UserOut(SessionUser):
    email: str
    created_at: UTCDateTime


class TokenOut(BaseModel):
    token: str
    user: SessionUser
