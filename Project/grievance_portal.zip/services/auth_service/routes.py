import asyncio
import hmac

import bcrypt
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from common.config import env
from common.events import AUTH_TOPIC, EventBus
from common.security import CurrentUser, create_access_token, get_current_user, require_internal_key, require_roles
from services.auth_service import schemas
from services.auth_service.database import get_session
from services.auth_service.models import User

router = APIRouter(prefix="/auth", tags=["auth"])
internal = APIRouter(prefix="/internal", tags=["internal"], dependencies=[Depends(require_internal_key)])

# Set by main.py so routes can publish without importing the app (avoids circular imports).
bus: EventBus | None = None


async def hash_password(password: str) -> str:
    return (await asyncio.to_thread(bcrypt.hashpw, password.encode(), bcrypt.gensalt())).decode()


async def verify_password(password: str, hashed: str) -> bool:
    return await asyncio.to_thread(bcrypt.checkpw, password.encode(), hashed.encode())


def _token_response(user: User) -> schemas.TokenOut:
    session_user = schemas.SessionUser.model_validate(user)
    token = create_access_token(CurrentUser(**session_user.model_dump()))
    return schemas.TokenOut(token=token, user=session_user)


async def _create_user(session: AsyncSession, name, email, password, role, department) -> User:
    user = User(
        name=name.strip(), email=str(email).strip().lower(), password_hash=await hash_password(password),
        role=role, department=department,
    )
    session.add(user)
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(409, "An account with that email already exists.")
    if bus:
        await bus.publish(AUTH_TOPIC, "user.registered", {"id": user.id, "name": user.name, "role": user.role})
    return user


@router.post("/login", response_model=schemas.TokenOut)
async def login(body: schemas.LoginIn, session: AsyncSession = Depends(get_session)):
    user = (await session.execute(select(User).where(User.email == body.email.strip().lower()))).scalar_one_or_none()
    # One generic message for both cases so the endpoint can't be used to enumerate accounts.
    if not user or not await verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password.")
    return _token_response(user)


@router.post("/register", response_model=schemas.TokenOut, status_code=201)
async def register(body: schemas.RegisterIn, session: AsyncSession = Depends(get_session)):
    """Open registration for students; faculty must present the institution's registration code
    (otherwise anyone could sign up as faculty and read every student's doubts)."""
    department = None
    if body.role == "faculty":
        expected = env("FACULTY_REGISTRATION_CODE", "FACULTY-2026") or ""
        if not body.faculty_code or not hmac.compare_digest(body.faculty_code.strip(), expected):
            raise HTTPException(403, "Invalid faculty registration code.")
        department = body.department.strip()  # type: ignore[union-attr]
    user = await _create_user(session, body.name, body.email, body.password, body.role, department)
    return _token_response(user)


@router.get("/me", response_model=schemas.UserOut)
async def me(current: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    user = await session.get(User, current.id)
    if not user:
        raise HTTPException(404, "Account no longer exists.")
    return user


@router.get("/users", response_model=list[schemas.UserOut], dependencies=[Depends(require_roles("admin"))])
async def list_users(role: schemas.Role | None = None, session: AsyncSession = Depends(get_session)):
    query = select(User).order_by(User.id)
    if role:
        query = query.where(User.role == role)
    return (await session.execute(query)).scalars().all()


@router.post("/users", response_model=schemas.UserOut, status_code=201, dependencies=[Depends(require_roles("admin"))])
async def create_user(body: schemas.UserCreateIn, session: AsyncSession = Depends(get_session)):
    return await _create_user(session, body.name, body.email, body.password, body.role, body.department)


@internal.get("/users/summary")
async def users_summary(session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(User.role, func.count()).group_by(User.role))).all()
    by_role = {role: count for role, count in rows}
    return {"total": sum(by_role.values()), "by_role": by_role}
