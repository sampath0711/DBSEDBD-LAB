import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from common.config import env, internal_api_key
from common.http import new_client
from common.security import get_current_user, require_internal_key, require_roles
from services.admin_service import schemas
from services.admin_service.database import get_session
from services.admin_service.models import Category

log = logging.getLogger("admin")

public = APIRouter(tags=["categories"], dependencies=[Depends(get_current_user)])
admin = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_roles("admin"))])
internal = APIRouter(prefix="/internal", tags=["internal"], dependencies=[Depends(require_internal_key)])


@public.get("/categories", response_model=list[schemas.CategoryPublic])
async def list_categories(session: AsyncSession = Depends(get_session)):
    return (await session.execute(select(Category).order_by(Category.name))).scalars().all()


@internal.get("/categories", response_model=list[schemas.CategoryPublic])
async def internal_categories(session: AsyncSession = Depends(get_session)):
    return (await session.execute(select(Category).order_by(Category.name))).scalars().all()


@admin.get("/categories", response_model=list[schemas.CategoryOut])
async def admin_list_categories(session: AsyncSession = Depends(get_session)):
    return (await session.execute(select(Category).order_by(Category.id))).scalars().all()


@admin.post("/categories", response_model=schemas.CategoryOut, status_code=201)
async def create_category(body: schemas.CategoryIn, session: AsyncSession = Depends(get_session)):
    category = Category(name=body.name.strip(), default_department=body.default_department.strip())
    session.add(category)
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(409, "A category with that name already exists.")
    return category


@admin.put("/categories/{category_id}", response_model=schemas.CategoryOut)
async def update_category(category_id: int, body: schemas.CategoryIn, session: AsyncSession = Depends(get_session)):
    category = await session.get(Category, category_id)
    if not category:
        raise HTTPException(404, "Category not found.")
    category.name, category.default_department = body.name.strip(), body.default_department.strip()
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(409, "A category with that name already exists.")
    return category


@admin.delete("/categories/{category_id}", status_code=204)
async def delete_category(category_id: int, session: AsyncSession = Depends(get_session)):
    category = await session.get(Category, category_id)
    if not category:
        raise HTTPException(404, "Category not found.")
    await session.delete(category)
    await session.commit()


async def _internal_get(base_url_env: str, default: str, path: str):
    async with new_client(env(base_url_env, default), timeout=5) as client:  # type: ignore[arg-type]
        response = await client.get(path, headers={"X-Internal-Key": internal_api_key()})
        response.raise_for_status()
        return response.json()


@admin.get("/overview")
async def overview():
    """Dashboard numbers aggregated from other services over REST.
    If one service is down we return what we have and list it under `degraded`."""
    result: dict = {"grievances": None, "users": None, "doubts": None, "degraded": []}
    for key, url_env, default, path in (
        ("grievances", "GRIEVANCE_SERVICE_URL", "http://localhost:8002", "/internal/stats"),
        ("users", "AUTH_SERVICE_URL", "http://localhost:8001", "/internal/users/summary"),
        ("doubts", "DOUBT_SERVICE_URL", "http://localhost:8005", "/internal/stats"),
    ):
        try:
            result[key] = await _internal_get(url_env, default, path)
        except Exception as exc:  # noqa: BLE001
            log.warning("overview: %s unavailable (%s)", key, exc)
            result["degraded"].append(key)
    return result
