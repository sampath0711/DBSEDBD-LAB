from pydantic import BaseModel, Field

from common.schemas import ORMModel


class CategoryIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    default_department: str = Field(min_length=2, max_length=120)


class CategoryOut(ORMModel):
    id: int
    name: str
    default_department: str


class CategoryPublic(ORMModel):
    """Shape the frontend already consumes."""
    name: str
    default_department: str
