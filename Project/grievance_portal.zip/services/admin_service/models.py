from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from services.admin_service.database import Base


class Category(Base):
    """A grievance category and the department it is routed to by default."""
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    default_department: Mapped[str] = mapped_column(String(120))
