from contextlib import asynccontextmanager

from sqlalchemy import func, select

from common.app_factory import create_app
from common.config import env_bool
from common.db import create_tables
from services.admin_service import routes
from services.admin_service.database import Base, SessionLocal, engine
from services.admin_service.models import Category

DEFAULT_CATEGORIES = [
    ("Academic", "Academic Affairs Office"),
    ("Examination", "Controller of Examinations"),
    ("Infrastructure", "Facilities & Maintenance"),
    ("Hostel", "Hostel Administration"),
    ("Administrative", "Registrar's Office"),
]


@asynccontextmanager
async def lifespan(app):
    await create_tables(engine, Base.metadata)
    if env_bool("SEED_DEMO_DATA", True):
        async with SessionLocal() as session:
            if (await session.execute(select(func.count()).select_from(Category))).scalar_one() == 0:
                session.add_all(Category(name=n, default_department=d) for n, d in DEFAULT_CATEGORIES)
                await session.commit()
    yield
    await engine.dispose()


app = create_app("Admin Service", "Categories, department routing rules and analytics (PostgreSQL).", lifespan)
app.include_router(routes.public)
app.include_router(routes.admin)
app.include_router(routes.internal)
