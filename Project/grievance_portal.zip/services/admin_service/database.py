from sqlalchemy.orm import DeclarativeBase

from common.config import env
from common.db import make_engine, make_session_factory

engine = make_engine(env("ADMIN_DATABASE_URL", "sqlite+aiosqlite:///./.data/admin.db"))
SessionLocal = make_session_factory(engine)


class Base(DeclarativeBase):
    pass


async def get_session():
    async with SessionLocal() as session:
        yield session
