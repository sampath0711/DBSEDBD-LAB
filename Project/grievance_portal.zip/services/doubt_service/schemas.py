from typing import Literal

from pydantic import BaseModel, Field

from common.schemas import ORMModel, UTCDateTime

DoubtStatus = Literal["Open", "Answered", "Resolved"]


class DoubtIn(BaseModel):
    subject: str = Field(min_length=2, max_length=80, examples=["Database Systems"])
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(min_length=10, max_length=5000)


class ReplyIn(BaseModel):
    body: str = Field(min_length=1, max_length=5000)


class StatusIn(BaseModel):
    status: Literal["Open", "Resolved"]


class ReplyOut(ORMModel):
    id: int
    author_id: int
    author_name: str
    author_role: str
    body: str
    created_at: UTCDateTime


class DoubtOut(ORMModel):
    id: int
    code: str
    subject: str
    title: str
    description: str
    status: str
    asked_by: int
    asked_by_name: str
    answered_by_name: str | None = None
    reply_count: int = 0
    created_at: UTCDateTime
    updated_at: UTCDateTime
    replies: list[ReplyOut] | None = None   # only populated on the detail endpoint


class DoubtStats(BaseModel):
    total: int
    open: int
    answered: int
    resolved: int
    mine: int   # faculty: doubts they have answered; students: same as total
