from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from common.schemas import utcnow
from services.doubt_service.database import Base


class Doubt(Base):
    """An academic question from a student, answered by faculty in a back-and-forth thread.

    Status:  Open      – waiting for a faculty reply (new, or the student followed up)
             Answered  – a faculty member replied; waiting on the student
             Resolved  – closed by the student or faculty
    """
    __tablename__ = "doubts"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    subject: Mapped[str] = mapped_column(String(80), index=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(12), default="Open", index=True)
    asked_by: Mapped[int] = mapped_column(index=True)             # user id (auth service)
    asked_by_name: Mapped[str] = mapped_column(String(120))
    answered_by: Mapped[int | None] = mapped_column(nullable=True)  # latest faculty responder
    answered_by_name: Mapped[str | None] = mapped_column(String(120), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Reply(Base):
    __tablename__ = "doubt_replies"

    id: Mapped[int] = mapped_column(primary_key=True)
    doubt_id: Mapped[int] = mapped_column(ForeignKey("doubts.id", ondelete="CASCADE"), index=True)
    author_id: Mapped[int] = mapped_column()
    author_name: Mapped[str] = mapped_column(String(120))
    author_role: Mapped[str] = mapped_column(String(20))
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
