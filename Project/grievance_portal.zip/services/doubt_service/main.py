from contextlib import asynccontextmanager

from common.app_factory import create_app
from common.config import env_bool
from common.db import create_tables
from common.events import get_bus
from services.doubt_service import routes
from services.doubt_service.database import Base, engine
from services.doubt_service.seed import seed_demo_doubts


@asynccontextmanager
async def lifespan(app):
    await create_tables(engine, Base.metadata)
    if env_bool("SEED_DEMO_DATA", True):
        await seed_demo_doubts()
    routes.bus = get_bus()
    await routes.bus.start()
    yield
    await routes.bus.stop()
    await engine.dispose()


app = create_app("Doubt Service", "Academic Q&A: students ask, faculty answer (PostgreSQL, Kafka events).", lifespan)
app.include_router(routes.router)
app.include_router(routes.internal)
