from datetime import timedelta

from sqlalchemy import func, select

from common.schemas import utcnow
from services.doubt_service.database import SessionLocal
from services.doubt_service.models import Doubt, Reply

# user ids refer to the auth service's demo users: 1 Ananya Rao, 2 Karthik Nair (students), 3 Ramesh Iyer (faculty)
ANANYA, KARTHIK, RAMESH = (1, "Ananya Rao", "student"), (2, "Karthik Nair", "student"), (3, "Ramesh Iyer", "faculty")

SEED = [
    dict(subject="Database Systems", title="Difference between 3NF and BCNF?", status="Resolved", by=ANANYA, days=9,
         desc="I understand both remove redundancy, but I can't see when a table is in 3NF and still not in BCNF. Could you give an example?",
         answered=RAMESH,
         thread=[(RAMESH, 8, "Take R(Student, Course, Teacher) with Teacher → Course and (Student, Course) → Teacher. It is in 3NF because Course is a prime attribute, but Teacher is not a superkey, so it violates BCNF. Decomposing into (Teacher, Course) and (Student, Teacher) fixes it."),
                 (ANANYA, 8, "That makes sense — the prime-attribute exception is what lets it pass 3NF. Thank you!")]),
    dict(subject="Operating Systems", title="Why does paging cause internal fragmentation?", status="Answered", by=ANANYA, days=3,
         desc="If memory is split into fixed-size frames, where exactly does the wasted space come from?", answered=RAMESH,
         thread=[(RAMESH, 2, "A process rarely needs an exact multiple of the page size, so its last page is only partly used. The unused tail of that final frame is internal fragmentation — on average about half a page per process.")]),
    dict(subject="Data Structures", title="Time complexity of building a heap", status="Open", by=KARTHIK, days=1,
         desc="Inserting n elements one by one costs O(n log n), but my notes say heapify is O(n). How is that possible?", answered=None, thread=[]),
]


async def seed_demo_doubts() -> None:
    async with SessionLocal() as session:
        if (await session.execute(select(func.count()).select_from(Doubt))).scalar_one() > 0:
            return
        now = utcnow()
        for s in SEED:
            d = Doubt(
                code="tmp", subject=s["subject"], title=s["title"], description=s["desc"], status=s["status"],
                asked_by=s["by"][0], asked_by_name=s["by"][1], created_at=now - timedelta(days=s["days"]),
                updated_at=now - timedelta(days=(s["thread"][-1][1] if s["thread"] else s["days"])),
                answered_by=s["answered"][0] if s["answered"] else None, answered_by_name=s["answered"][1] if s["answered"] else None,
            )
            session.add(d)
            await session.flush()
            d.code = f"DBT-{1000 + d.id}"
            for (uid, name, role), days_ago, body in s["thread"]:
                session.add(Reply(doubt_id=d.id, author_id=uid, author_name=name, author_role=role, body=body,
                                  created_at=now - timedelta(days=days_ago)))
        await session.commit()
