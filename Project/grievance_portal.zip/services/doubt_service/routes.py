import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select, true
from sqlalchemy.ext.asyncio import AsyncSession

from common.events import DOUBT_TOPIC, EventBus
from common.security import CurrentUser, get_current_user, require_internal_key, require_roles
from services.doubt_service import schemas
from services.doubt_service.database import get_session
from services.doubt_service.models import Doubt, Reply

router = APIRouter(prefix="/doubts", tags=["doubts"])
internal = APIRouter(prefix="/internal", tags=["internal"], dependencies=[Depends(require_internal_key)])
bus: EventBus | None = None  # injected by main.py

READERS = ("student", "faculty", "admin")


# ---------------------------------------------------------------- helpers
def visible_to(user: CurrentUser):
    """Students only ever see their own doubts; faculty (who answer them) and admins see all."""
    return Doubt.asked_by == user.id if user.role == "student" else true()


async def _load(session: AsyncSession, doubt_id: int, user: CurrentUser) -> Doubt:
    d = await session.get(Doubt, doubt_id)
    if not d:
        raise HTTPException(404, "Doubt not found.")
    if user.role == "student" and d.asked_by != user.id:
        raise HTTPException(403, "You do not have access to this doubt.")
    if user.role not in READERS:
        raise HTTPException(403, "You do not have access to this doubt.")
    return d


async def _reply_counts(session: AsyncSession, ids: list[int]) -> dict[int, int]:
    if not ids:
        return {}
    rows = (await session.execute(
        select(Reply.doubt_id, func.count()).where(Reply.doubt_id.in_(ids)).group_by(Reply.doubt_id)
    )).all()
    return {i: c for i, c in rows}


async def _serialize(session: AsyncSession, doubts: list[Doubt], with_replies: bool = False) -> list[schemas.DoubtOut]:
    counts = await _reply_counts(session, [d.id for d in doubts])
    out = []
    for d in doubts:
        item = schemas.DoubtOut.model_validate(d)
        item.reply_count = counts.get(d.id, 0)
        if with_replies:
            replies = (await session.execute(
                select(Reply).where(Reply.doubt_id == d.id).order_by(Reply.created_at, Reply.id)
            )).scalars().all()
            item.replies = [schemas.ReplyOut.model_validate(r) for r in replies]
        out.append(item)
    return out


async def _publish(event_type: str, d: Doubt, actor: CurrentUser, **extra) -> None:
    if bus:
        await bus.publish(DOUBT_TOPIC, event_type, {
            "id": d.id, "code": d.code, "subject": d.subject, "title": d.title, "status": d.status,
            "asked_by": d.asked_by, "asked_by_name": d.asked_by_name, "answered_by": d.answered_by,
            "actor_id": actor.id, "actor_name": actor.name, "actor_role": actor.role, **extra,
        })


# ---------------------------------------------------------------- create / list
@router.post("", response_model=schemas.DoubtOut, status_code=201, dependencies=[Depends(require_roles("student"))])
async def ask_doubt(body: schemas.DoubtIn, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    d = Doubt(
        code=f"tmp-{uuid.uuid4().hex[:12]}", subject=body.subject.strip(), title=body.title.strip(),
        description=body.description.strip(), status="Open", asked_by=user.id, asked_by_name=user.name,
    )
    session.add(d)
    await session.flush()
    d.code = f"DBT-{1000 + d.id}"      # derived from the row id: unique even under concurrent submissions
    await session.commit()
    await _publish("doubt.created", d, user)
    return (await _serialize(session, [d], with_replies=True))[0]


@router.get("", response_model=list[schemas.DoubtOut], dependencies=[Depends(require_roles(*READERS))])
async def list_doubts(
    status: schemas.DoubtStatus | None = None,
    subject: str | None = Query(None, description="Exact subject"),
    answered_by_me: bool = False,
    user: CurrentUser = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    query = select(Doubt).where(visible_to(user)).order_by(Doubt.created_at.desc(), Doubt.id.desc())
    if status:
        query = query.where(Doubt.status == status)
    if subject:
        query = query.where(func.lower(Doubt.subject) == subject.strip().lower())
    if answered_by_me:
        query = query.where(Doubt.answered_by == user.id)
    return await _serialize(session, list((await session.execute(query)).scalars().all()))


@router.get("/stats", response_model=schemas.DoubtStats, dependencies=[Depends(require_roles(*READERS))])
async def stats(user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(
        select(Doubt.status, func.count()).where(visible_to(user)).group_by(Doubt.status)
    )).all()
    by = {s: c for s, c in rows}
    total = sum(by.values())
    mine = total
    if user.role != "student":
        mine = (await session.execute(select(func.count()).where(Doubt.answered_by == user.id))).scalar_one()
    return schemas.DoubtStats(total=total, open=by.get("Open", 0), answered=by.get("Answered", 0),
                              resolved=by.get("Resolved", 0), mine=mine)


@router.get("/subjects", response_model=list[str], dependencies=[Depends(require_roles(*READERS))])
async def subjects(user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(Doubt.subject).where(visible_to(user)).distinct().order_by(Doubt.subject))).scalars().all()
    return list(rows)


@router.get("/{doubt_id}", response_model=schemas.DoubtOut)
async def get_doubt(doubt_id: int, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    d = await _load(session, doubt_id, user)
    return (await _serialize(session, [d], with_replies=True))[0]


# ---------------------------------------------------------------- thread
@router.post("/{doubt_id}/replies", response_model=schemas.DoubtOut, status_code=201,
             dependencies=[Depends(require_roles("student", "faculty"))])
async def reply(doubt_id: int, body: schemas.ReplyIn, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    d = await _load(session, doubt_id, user)
    if d.status == "Resolved":
        raise HTTPException(409, "This doubt is resolved. Reopen it to continue the conversation.")

    session.add(Reply(doubt_id=d.id, author_id=user.id, author_name=user.name, author_role=user.role, body=body.body.strip()))
    if user.role == "faculty":
        d.status, d.answered_by, d.answered_by_name = "Answered", user.id, user.name
    else:                                   # the student followed up -> needs faculty attention again
        d.status = "Open"
    await session.commit()
    await _publish("doubt.replied", d, user, snippet=body.body.strip()[:140])
    return (await _serialize(session, [d], with_replies=True))[0]


@router.patch("/{doubt_id}", response_model=schemas.DoubtOut, dependencies=[Depends(require_roles("student", "faculty"))])
async def set_status(doubt_id: int, body: schemas.StatusIn, user: CurrentUser = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    """Student: resolve or reopen their own doubt.  Faculty: resolve any doubt (cannot reopen)."""
    d = await _load(session, doubt_id, user)
    if user.role == "faculty" and body.status != "Resolved":
        raise HTTPException(403, "Only the student who asked can reopen a doubt.")
    if d.status == body.status:
        return (await _serialize(session, [d], with_replies=True))[0]
    d.status = body.status
    await session.commit()
    await _publish("doubt.resolved" if body.status == "Resolved" else "doubt.reopened", d, user)
    return (await _serialize(session, [d], with_replies=True))[0]


# ---------------------------------------------------------------- internal
@internal.get("/stats")
async def internal_stats(session: AsyncSession = Depends(get_session)):
    rows = (await session.execute(select(Doubt.status, func.count()).group_by(Doubt.status))).all()
    by_status = {s: c for s, c in rows}
    subjects = (await session.execute(
        select(Doubt.subject, func.count()).group_by(Doubt.subject).order_by(func.count().desc()).limit(5)
    )).all()
    total = sum(by_status.values())
    return {
        "total": total, "open": by_status.get("Open", 0), "answered": by_status.get("Answered", 0),
        "resolved": by_status.get("Resolved", 0), "top_subjects": {s: c for s, c in subjects},
    }
