from pydantic import BaseModel

from common.schemas import UTCDateTime


class NotificationOut(BaseModel):
    id: str
    kind: str
    message: str
    case_code: str | None = None
    grievance_id: int | None = None
    doubt_id: int | None = None
    read: bool
    created_at: UTCDateTime


class UnreadCount(BaseModel):
    unread: int
