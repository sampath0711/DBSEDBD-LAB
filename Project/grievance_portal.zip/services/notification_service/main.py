from contextlib import asynccontextmanager

from common.app_factory import create_app
from common.events import AUTH_TOPIC, DOUBT_TOPIC, GRIEVANCE_TOPIC, get_bus
from services.notification_service import handlers, routes
from services.notification_service.database import mongo


@asynccontextmanager
async def lifespan(app):
    await mongo()["notifications"].create_index([("user_id", 1), ("created_at", -1)])
    await mongo()["notifications"].create_index([("department", 1), ("created_at", -1)])
    bus = get_bus()
    bus.subscribe(GRIEVANCE_TOPIC, "notification-service", handlers.handle_grievance_event)
    bus.subscribe(AUTH_TOPIC, "notification-service", handlers.handle_auth_event)
    bus.subscribe(DOUBT_TOPIC, "notification-service", handlers.handle_doubt_event)
    await bus.start()
    yield
    await bus.stop()


app = create_app("Notification Service", "Kafka consumer that stores in-app notifications (MongoDB).", lifespan)
app.include_router(routes.router)
