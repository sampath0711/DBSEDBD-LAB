from common.config import env
from common.mongo import get_mongo_db

MONGO_DB_NAME = env("NOTIFICATION_MONGO_DB", "notifications")


def mongo():
    return get_mongo_db(MONGO_DB_NAME)
