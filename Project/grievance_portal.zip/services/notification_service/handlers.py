"""Turns domain events from Kafka into per-audience notification documents.

Audiences: a specific user (`user_id`), everyone staffing a department (`department`),
or all administrators (`admin`). Department/admin notices are single shared documents with a
`read_by` list, so each person's read-state is tracked independently.
"""
import logging

from pymongo.errors import DuplicateKeyError

from common.schemas import utcnow
from services.notification_service.database import mongo

log = logging.getLogger("notifications")


async def _first_delivery(event_id: str) -> bool:
    """Kafka is at-least-once; recording event ids makes processing idempotent."""
    try:
        await mongo()["processed_events"].insert_one({"_id": event_id, "at": utcnow()})
        return True
    except DuplicateKeyError:
        log.info("Duplicate event %s ignored", event_id)
        return False


def _doc(event: dict, message: str, *, user_id=None, department=None, admin=False, role=None) -> dict:
    d = event["data"]
    kind = event["type"]
    return {
        "event_id": event["event_id"], "kind": kind, "message": message,
        "grievance_id": d.get("id") if kind.startswith("grievance") else None,
        "doubt_id": d.get("id") if kind.startswith("doubt") else None,
        "case_code": d.get("case_code") or d.get("code"),
        "user_id": user_id, "department": department, "admin": admin, "role": role,
        "read_by": [], "created_at": utcnow(),
    }


def _grievance_docs(event: dict) -> list[dict]:
    t, d = event["type"], event["data"]
    code, owner, actor = d["case_code"], d["submitted_by"], d.get("actor_id")
    docs: list[dict] = []

    if t == "grievance.created":
        docs.append(_doc(event, f"Your grievance {code} was submitted and routed to {d['department']}.", user_id=owner))
        docs.append(_doc(event, f"New {d['priority']} grievance {code}: {d['title']}", department=d["department"]))
        if d["priority"] == "Urgent":
            docs.append(_doc(event, f"Urgent grievance {code} raised in {d['department']}.", admin=True))

    elif t == "grievance.updated":
        if d.get("old_status") and d["old_status"] != d["status"] and owner != actor:
            docs.append(_doc(event, f"{code} moved from {d['old_status']} to {d['status']}.", user_id=owner))
        if d.get("old_department") and d["old_department"] != d["department"]:
            docs.append(_doc(event, f"{code} was reassigned to your department.", department=d["department"]))
            if owner != actor:
                docs.append(_doc(event, f"{code} was reassigned to {d['department']}.", user_id=owner))
        if d.get("note") and owner != actor:
            docs.append(_doc(event, f"New update on {code}: {d['note'][:140]}", user_id=owner))

    elif t == "grievance.commented":
        if owner != actor:
            docs.append(_doc(event, f"{d['actor_name']} commented on {code}.", user_id=owner))
        else:
            docs.append(_doc(event, f"The complainant commented on {code}.", department=d["department"]))
    return docs


async def handle_grievance_event(event: dict) -> None:
    if not await _first_delivery(event["event_id"]):
        return
    docs = _grievance_docs(event)
    if docs:
        await mongo()["notifications"].insert_many(docs)


def _doubt_docs(event: dict) -> list[dict]:
    """Doubts are a conversation between the asking student and faculty:
    a new/reopened doubt alerts faculty (the last responder if known, else all faculty);
    replies and resolutions alert the other side."""
    t, d = event["type"], event["data"]
    code, asker, answerer = d["code"], d["asked_by"], d.get("answered_by")
    actor, actor_name, actor_role = d.get("actor_id"), d["actor_name"], d.get("actor_role")

    def to_faculty(message: str) -> dict:
        return _doc(event, message, user_id=answerer) if answerer else _doc(event, message, role="faculty")

    if t == "doubt.created":
        return [_doc(event, f"New doubt {code} in {d['subject']}: {d['title']}", role="faculty")]
    if t == "doubt.replied":
        if actor_role == "faculty":
            return [_doc(event, f"{actor_name} answered your doubt {code}.", user_id=asker)]
        return [to_faculty(f"{actor_name} sent a follow-up on {code}: {d.get('snippet', '')[:100]}")]
    if t == "doubt.resolved":
        if actor_role == "faculty":
            return [_doc(event, f"{actor_name} marked your doubt {code} as resolved.", user_id=asker)]
        return [to_faculty(f"{actor_name} marked {code} as resolved.")] if answerer else []
    if t == "doubt.reopened":
        return [to_faculty(f"{actor_name} reopened {code}.")]
    return []


async def handle_doubt_event(event: dict) -> None:
    if not await _first_delivery(event["event_id"]):
        return
    docs = [x for x in _doubt_docs(event) if x["user_id"] != event["data"].get("actor_id") or x["role"]]
    if docs:
        await mongo()["notifications"].insert_many(docs)


async def handle_auth_event(event: dict) -> None:
    if event["type"] != "user.registered" or not await _first_delivery(event["event_id"]):
        return
    d = event["data"]
    doc = {
        "event_id": event["event_id"], "kind": event["type"], "grievance_id": None, "case_code": None,
        "message": f"Welcome, {d['name']}! You can now submit and track grievances.",
        "user_id": d["id"], "department": None, "admin": False, "role": None, "doubt_id": None,
        "read_by": [], "created_at": utcnow(),
    }
    await mongo()["notifications"].insert_one(doc)
