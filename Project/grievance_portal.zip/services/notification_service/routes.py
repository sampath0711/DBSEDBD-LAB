from bson import ObjectId
from bson.errors import InvalidId
from fastapi import APIRouter, Depends, HTTPException, Query

from common.security import CurrentUser, get_current_user
from services.notification_service import schemas
from services.notification_service.database import mongo

router = APIRouter(prefix="/notifications", tags=["notifications"])


def _audience(user: CurrentUser) -> dict:
    clauses: list[dict] = [{"user_id": user.id}]
    if user.role == "staff" and user.department:
        clauses.append({"department": user.department})
    if user.role == "admin":
        clauses.append({"admin": True})
    if user.role == "faculty":
        clauses.append({"role": "faculty"})        # broadcast to all faculty (e.g. a new student doubt)
    return {"$or": clauses}


def _out(doc: dict, user: CurrentUser) -> schemas.NotificationOut:
    return schemas.NotificationOut(
        id=str(doc["_id"]), kind=doc["kind"], message=doc["message"], case_code=doc.get("case_code"),
        grievance_id=doc.get("grievance_id"), doubt_id=doc.get("doubt_id"), read=user.id in doc.get("read_by", []), created_at=doc["created_at"],
    )


@router.get("", response_model=list[schemas.NotificationOut])
async def list_notifications(
    unread_only: bool = False, limit: int = Query(30, ge=1, le=100), user: CurrentUser = Depends(get_current_user),
):
    query = _audience(user)
    if unread_only:
        query = {"$and": [query, {"read_by": {"$ne": user.id}}]}
    docs = await mongo()["notifications"].find(query).sort([("created_at", -1), ("_id", -1)]).to_list(limit)
    return [_out(d, user) for d in docs]


@router.get("/unread-count", response_model=schemas.UnreadCount)
async def unread_count(user: CurrentUser = Depends(get_current_user)):
    query = {"$and": [_audience(user), {"read_by": {"$ne": user.id}}]}
    return {"unread": await mongo()["notifications"].count_documents(query)}


@router.post("/read-all", response_model=schemas.UnreadCount)
async def mark_all_read(user: CurrentUser = Depends(get_current_user)):
    query = {"$and": [_audience(user), {"read_by": {"$ne": user.id}}]}
    await mongo()["notifications"].update_many(query, {"$addToSet": {"read_by": user.id}})
    return {"unread": 0}


@router.post("/{notification_id}/read", response_model=schemas.NotificationOut)
async def mark_read(notification_id: str, user: CurrentUser = Depends(get_current_user)):
    try:
        oid = ObjectId(notification_id)
    except InvalidId:
        raise HTTPException(404, "Notification not found.")
    query = {"$and": [{"_id": oid}, _audience(user)]}  # you can only touch notifications addressed to you
    doc = await mongo()["notifications"].find_one(query)
    if not doc:
        raise HTTPException(404, "Notification not found.")
    await mongo()["notifications"].update_one({"_id": oid}, {"$addToSet": {"read_by": user.id}})
    doc["read_by"] = [*doc.get("read_by", []), user.id]
    return _out(doc, user)
