-- Database-per-service: each microservice owns its schema and nobody else connects to it.
CREATE DATABASE auth_db;
CREATE DATABASE grievance_db;
CREATE DATABASE admin_db;
CREATE DATABASE doubt_db;
