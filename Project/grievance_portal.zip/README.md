# Grievance Redressal Portal — FastAPI Microservices

Backend for the *Grievance Redressal Portal for Institutions* project (25CS1302E): your existing
frontend, rebuilt on **FastAPI microservices**, **PostgreSQL + MongoDB**, **JWT**, **Kafka** and **Docker**,
with a **Postman** collection for API testing and a **CI** pipeline.

Beyond grievances it includes **academic doubts** (students ask, faculty answer in a thread) and **self-registration** for students and faculty.

The REST contract of the original Node/Express app is preserved, so `frontend/index.html` works unchanged
(one line fixed — see *Changes from the Node version*).

## Architecture

```mermaid
flowchart LR
  FE[Browser / Postman] --> GW[API Gateway :8000<br/>routing · login rate-limit · serves frontend]
  GW --> AUTH[Auth Service :8001<br/>users · JWT]
  GW --> GRV[Grievance Service :8002<br/>cases · triage · search]
  GW --> NOT[Notification Service :8003]
  GW --> ADM[Admin Service :8004<br/>categories · analytics]
  GW --> DBT[Doubt Service :8005<br/>academic Q&A threads]
  AUTH --- PGA[(PostgreSQL<br/>auth_db)]
  GRV --- PGG[(PostgreSQL<br/>grievance_db)]
  GRV --- MG1[(MongoDB<br/>timeline + classifier output)]
  ADM --- PGD[(PostgreSQL<br/>admin_db)]
  DBT --- PGB[(PostgreSQL<br/>doubt_db)]
  NOT --- MG2[(MongoDB<br/>notifications)]
  GRV -- grievance.events --> K{{Kafka}}
  AUTH -- auth.events --> K
  DBT -- doubt.events --> K
  K --> NOT
  GRV -. REST: category→department .-> ADM
  ADM -. REST: stats .-> GRV
  ADM -. REST: user counts .-> AUTH
```

| Service | Owns | Highlights |
|---|---|---|
| **gateway** | – | Path routing `/api/*`, login throttling, aggregate `/api/health`, 503/504 on upstream failure, `X-Request-ID` propagation, serves the SPA. `/internal/*` is never routable. |
| **auth_service** | `auth_db` (PostgreSQL) | bcrypt passwords, JWT (HS256), self-registration for students/faculty, admin-created staff/admin accounts, generic login error (no account enumeration). |
| **grievance_service** | `grievance_db` (PostgreSQL) + MongoDB | Case CRUD with SQL-level row visibility, auto-categorisation & priority triage (keyword rules, explainable), timeline + comments in Mongo, TF-IDF similar-case search, publishes Kafka events. |
| **notification_service** | MongoDB | Kafka consumer; per-user, per-department and admin audiences; idempotent (duplicate deliveries ignored); per-user read state. |
| **doubt_service** | `doubt_db` (PostgreSQL) | Students post academic doubts, faculty answer in a threaded conversation. Status `Open` (needs faculty) → `Answered` (needs student) → `Resolved`. Students see only their own; faculty see all; admin read-only. Publishes `doubt.*` events. |
| **admin_service** | `admin_db` (PostgreSQL) | Category → department routing rules (CRUD), cross-service overview dashboard that degrades gracefully if a service is down. |

Each service has its own database (no shared tables) and verifies the JWT itself. Service-to-service
endpoints (`/internal/*`) require an `X-Internal-Key` header.

**Kafka topics:** `grievance.events` (`grievance.created`, `grievance.updated`, `grievance.commented`),
`doubt.events` (`doubt.created`, `doubt.replied`, `doubt.resolved`, `doubt.reopened`) and `auth.events` (`user.registered`). Envelope: `{event_id, type, occurred_at, data}`.

## Run it

### A) Docker (full stack: PostgreSQL, MongoDB, Kafka, 5 services)
```bash
cp .env.example .env        # optional — defaults work for a demo
docker compose up --build
```
Open **http://localhost:8000**. Swagger UI per service: http://localhost:8001/docs (auth), `:8002/docs` (grievance),
`:8003/docs` (notification), `:8004/docs` (admin), `:8005/docs` (doubts).

> **Upgrading an existing Docker setup?** PostgreSQL only runs `infra/postgres/init.sql` on a fresh volume, so the new `doubt_db`
> won't exist. Run `docker compose down -v` first (this deletes the demo data), then `docker compose up --build`.

### B) No Docker (single process — SQLite + in-memory Mongo/Kafka)
```bash
pip install -r requirements-dev.txt
python scripts/run_dev.py          # http://localhost:8000 — data is wiped on every start
```
The services still call each other through HTTP-shaped ASGI transports, so request flows are the same as in Docker.

### Demo accounts (password `password123`)
`ananya.rao@campus.edu` (student) · `karthik.nair@campus.edu` (student) · `ramesh.iyer@campus.edu` (faculty) ·
`priya.menon@campus.edu` (staff, Registrar's Office) · `divya.kumar@campus.edu` (staff, Hostel Administration) · `admin@campus.edu` (admin)

## Registration (student & faculty)
On the sign-in page of the **Student** or **Faculty** role, click *Create an account*.
- **Students** register freely (name, email, password ≥ 8 chars) and are signed in immediately.
- **Faculty** also give a department and the **faculty registration code** (default `FACULTY-2026`, set `FACULTY_REGISTRATION_CODE` in `.env`).
  Without a code check anyone could register as faculty and read every student's doubts. **Change the default before deploying.**
- Staff and admin accounts can only be created by an admin (`POST /api/auth/users`).

## Academic doubts
- **Student:** *Ask a Doubt* (subject, question, details) → *My Doubts* to follow the thread, add follow-ups, mark resolved or reopen.
- **Faculty:** *Student Doubts* is the desk (defaults to doubts needing a reply; filter by status, subject, "answered by me"),
  open a doubt to answer it or mark it resolved. Any faculty member can answer any doubt.
- Nav badges: faculty see how many doubts await a reply; students see how many have been answered.
- Notifications (via Kafka → notification service): new doubt → all faculty; faculty answer → the student; a student follow-up or
  resolution → the faculty member who last answered.

## Postman
1. Import `postman/GrievancePortal.postman_collection.json` and `postman/Local.postman_environment.json`; select the environment.
2. Run the collection top-to-bottom (**Runner**) — 71 requests, 129 assertions (plus 5 direct-service health checks in the last folder). Logins store JWTs in variables, creating a
   grievance stores `grievance_id`, and later requests reuse them. Folder 7 (direct service health) only works with Docker.
3. CLI: `npx newman run postman/GrievancePortal.postman_collection.json -e postman/Local.postman_environment.json --folder "1 · Auth" …`

## API summary (via gateway, `Authorization: Bearer <token>`)
| Method & path | Who | Notes |
|---|---|---|
| `POST /api/auth/login` · `/register` | public | register → student/faculty only |
| `GET /api/auth/me` · `GET/POST /api/auth/users` | user · admin | |
| `POST /api/auth/register` (faculty adds `department`, `faculty_code`) | public | student / faculty only |
| `GET /api/categories` | any | category → department map |
| `GET /api/grievances?status=&category=&priority=` | any | scoped: owner / department staff / admin |
| `POST /api/grievances` | any | omit `category`/`priority` to auto-classify |
| `GET /api/grievances/{id}` · `/stats` · `/search?q=` · `/{id}/similar` | any | |
| `PATCH /api/grievances/{id}` | staff (own dept) · admin | status, department, priority, assigned_to, note |
| `POST /api/grievances/{id}/comments` | anyone with access | |
| `POST /api/doubts` | student | `{subject, title, description}` |
| `GET /api/doubts?status=&subject=&answered_by_me=` · `/stats` · `/subjects` · `/{id}` | student (own) · faculty · admin | staff → 403 |
| `POST /api/doubts/{id}/replies` | asking student · faculty | faculty reply → *Answered*; student follow-up → *Open*; 409 once resolved |
| `PATCH /api/doubts/{id}` `{status: Open\|Resolved}` | student (resolve/reopen) · faculty (resolve) | |
| `GET /api/notifications` · `/unread-count` · `POST /{id}/read` · `/read-all` | any | |
| `GET /api/admin/overview` · `/api/admin/categories` CRUD | admin | |
| `GET /api/health` | public | aggregate service health |

## Tests
```bash
python -m pytest -q       # 53 tests: auth + registration, visibility rules, routing, triage, doubts workflow, events, idempotency, gateway failure modes
```
CI (`.github/workflows/ci.yml`): pytest → Newman against the dev stack → `docker build` of all six images.

## Changes from the Node version
- MySQL → **PostgreSQL** (+ MongoDB for timeline/flexible data). Case codes for new cases are `GRC-<1000+id>` (derived from the row id, so concurrent submissions can't collide; the old "last code + 1" approach could).
- Login returns one generic error instead of distinguishing "no account" vs "wrong password".
- Validation errors are `422` (FastAPI standard) rather than `400`; body is still `{"error": "..."}`.
- `frontend/index.html`: a failed **login** (401) no longer triggers the "session expired" logout path.
- New: registration (student/faculty), academic doubts, notifications, comments, similar-case search, auto-classification, admin category CRUD/overview.

## Known limitations / next steps
- **Events can be lost** if Kafka is down at publish time (request still succeeds, error is logged). Production fix: transactional outbox.
- Tables are created at startup (`create_all`); use **Alembic** for real schema migrations.
- Triage and similarity are lexical (keyword rules, TF-IDF). `classifier.classify` and `similarity.rank` are the seams for an ML model / sentence-embedding index.
- The gateway rate-limiter is per-process in-memory; use Redis or an edge proxy with multiple replicas.
- Secrets in `.env.example` are placeholders — set real `JWT_SECRET` and `INTERNAL_API_KEY` before deploying.
- The frontend does not yet show notifications (API is ready: `/api/notifications`); doubt status is visible via the nav badges and thread view.
- Faculty registration is gated by one shared code. An admin-approval queue (pending → approved) would be stricter; any faculty member can answer any doubt (no subject/course assignment yet).
