"""Start the full portal (frontend + gateway + 4 services) in ONE process on http://localhost:8000.
Data is ephemeral: it is wiped on every start. Great for a quick demo or for Postman/newman runs."""
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import uvicorn  # noqa: E402

from devstack import build_stack  # noqa: E402

if __name__ == "__main__":
    data_dir = ROOT / ".devdata"
    shutil.rmtree(data_dir, ignore_errors=True)
    app = build_stack(str(data_dir))
    print("Dev stack (SQLite + in-memory Mongo/Kafka) -> http://localhost:8000   docs per service via Docker compose")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
