
"""Run the whole system inside one Python process without Docker.

SQLite replaces PostgreSQL, mongomock replaces MongoDB, and an in-process
bus replaces Kafka. The gateway exposes a combined OpenAPI schema for
the public APIs of all microservices.
"""

import os
from copy import deepcopy
from contextlib import AsyncExitStack, asynccontextmanager

import httpx

SERVICE_URLS = {
    "AUTH_SERVICE_URL": "http://auth-service",
    "GRIEVANCE_SERVICE_URL": "http://grievance-service",
    "NOTIFICATION_SERVICE_URL": "http://notification-service",
    "ADMIN_SERVICE_URL": "http://admin-service",
    "DOUBT_SERVICE_URL": "http://doubt-service",
}


def build_stack(data_dir: str):
    """Configure services and return the gateway ASGI app."""
    os.makedirs(data_dir, exist_ok=True)

    pg = os.environ.get("DEVSTACK_PG_URL_TEMPLATE")
    db_url = (
        lambda db: pg.format(db=db)
        if pg
        else f"sqlite+aiosqlite:///{data_dir}/{db}.db"
    )

    forced = {
        "AUTH_DATABASE_URL": db_url("auth_db"),
        "GRIEVANCE_DATABASE_URL": db_url("grievance_db"),
        "ADMIN_DATABASE_URL": db_url("admin_db"),
        "DOUBT_DATABASE_URL": db_url("doubt_db"),
        "MONGO_URI": "mongomock://in-memory",
        "KAFKA_BOOTSTRAP_SERVERS": "",
        **SERVICE_URLS,
    }

    os.environ.update(forced)
    os.environ.setdefault("JWT_SECRET", "dev-secret-change-me")
    os.environ.setdefault("INTERNAL_API_KEY", "dev-internal-key")
    os.environ.setdefault("SEED_DEMO_DATA", "true")

    from common.http import register_transport
    from services.admin_service.main import app as admin_app
    from services.auth_service.main import app as auth_app
    from services.doubt_service.main import app as doubt_app
    from services.gateway.main import app as gateway_app
    from services.grievance_service.main import app as grievance_app
    from services.notification_service.main import app as notification_app

    apps = {
        SERVICE_URLS["AUTH_SERVICE_URL"]: auth_app,
        SERVICE_URLS["GRIEVANCE_SERVICE_URL"]: grievance_app,
        SERVICE_URLS["NOTIFICATION_SERVICE_URL"]: notification_app,
        SERVICE_URLS["ADMIN_SERVICE_URL"]: admin_app,
        SERVICE_URLS["DOUBT_SERVICE_URL"]: doubt_app,
    }

    for url, asgi_app in apps.items():
        register_transport(url, httpx.ASGITransport(app=asgi_app))

    gateway_lifespan = gateway_app.router.lifespan_context

    @asynccontextmanager
    async def combined(app):
        async with AsyncExitStack() as stack:
            for svc in (
                notification_app,
                admin_app,
                auth_app,
                grievance_app,
                doubt_app,
            ):
                await stack.enter_async_context(
                    svc.router.lifespan_context(svc)
                )

            await stack.enter_async_context(gateway_lifespan(app))
            yield

    gateway_app.router.lifespan_context = combined

    # Combine the public API documentation from all services.
    original_openapi = gateway_app.openapi

    service_configs = [
        (auth_app, ["/auth"]),
        (grievance_app, ["/grievances"]),
        (admin_app, ["/categories", "/admin"]),
        (notification_app, ["/notifications"]),
        (doubt_app, ["/doubts"]),
    ]

    def combined_openapi():
        if gateway_app.openapi_schema:
            return gateway_app.openapi_schema

        schema = deepcopy(original_openapi())
        schema["paths"] = {}

        components = schema.setdefault("components", {})
        components.setdefault("schemas", {})

        for service_app, allowed_prefixes in service_configs:
            service_schema = service_app.openapi()

            for path, methods in service_schema.get("paths", {}).items():
                if not any(
                    path == prefix or path.startswith(prefix + "/")
                    for prefix in allowed_prefixes
                ):
                    continue

                public_path = "/api" + path

                schema["paths"][public_path] = deepcopy(methods)

            service_components = service_schema.get("components", {})

            for component_type, definitions in service_components.items():
                target = components.setdefault(component_type, {})

                for name, definition in definitions.items():
                    if name not in target:
                        target[name] = deepcopy(definition)

        gateway_app.openapi_schema = schema
        return schema

    gateway_app.openapi = combined_openapi

    return gateway_app

print("Swagger UI: http://127.0.0.1:8000/docs")
