import pathlib
import sys
import tempfile

import pytest
from starlette.testclient import TestClient

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from devstack import build_stack  # noqa: E402


@pytest.fixture(scope="session")
def client():
    """Gateway + all four services, wired in-process (SQLite, mongomock, in-memory bus)."""
    app = build_stack(tempfile.mkdtemp(prefix="grc-test-"))
    with TestClient(app) as c:
        yield c


def _login(client, email, password="password123"):
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="session")
def student(client):
    return _login(client, "ananya.rao@campus.edu")


@pytest.fixture(scope="session")
def student2(client):
    return _login(client, "karthik.nair@campus.edu")


@pytest.fixture(scope="session")
def faculty(client):
    return _login(client, "ramesh.iyer@campus.edu")


@pytest.fixture(scope="session")
def hostel_staff(client):
    return _login(client, "divya.kumar@campus.edu")


@pytest.fixture(scope="session")
def registrar_staff(client):
    return _login(client, "priya.menon@campus.edu")


@pytest.fixture(scope="session")
def admin(client):
    return _login(client, "admin@campus.edu")
