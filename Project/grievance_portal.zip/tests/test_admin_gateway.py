from services.gateway.ratelimit import SlidingWindowLimiter


def test_category_list_for_frontend(client, student):
    cats = client.get("/api/categories", headers=student).json()
    assert {"name": "Hostel", "default_department": "Hostel Administration"} in cats
    assert client.get("/api/categories").status_code == 401


def test_category_crud_is_admin_only(client, student, admin):
    payload = {"name": "Library", "default_department": "Library Services"}
    assert client.post("/api/admin/categories", json=payload, headers=student).status_code == 403
    created = client.post("/api/admin/categories", json=payload, headers=admin)
    assert created.status_code == 201
    cid = created.json()["id"]
    assert client.post("/api/admin/categories", json=payload, headers=admin).status_code == 409
    upd = client.put(f"/api/admin/categories/{cid}", json={"name": "Library", "default_department": "Central Library"}, headers=admin)
    assert upd.json()["default_department"] == "Central Library"
    assert client.delete(f"/api/admin/categories/{cid}", headers=admin).status_code == 204
    assert client.delete(f"/api/admin/categories/{cid}", headers=admin).status_code == 404


def test_new_category_is_used_for_routing(client, student, admin):
    from services.grievance_service import categories
    client.post("/api/admin/categories", json={"name": "Transport", "default_department": "Transport Office"}, headers=admin)
    categories.invalidate_cache()           # the grievance service caches the category map for 30 s
    r = client.post("/api/grievances", json={"title": "Bus route 5 skipped", "description": "College bus route 5 skipped our stop twice this week.", "category": "Transport"}, headers=student)
    assert r.status_code == 201 and r.json()["department"] == "Transport Office"


def test_admin_overview_aggregates_other_services(client, admin, student):
    o = client.get("/api/admin/overview", headers=admin).json()
    assert o["degraded"] == []
    assert o["grievances"]["total"] >= 6 and "by_department" in o["grievances"]
    assert o["users"]["by_role"]["admin"] == 1
    assert o["doubts"]["total"] >= 3 and "top_subjects" in o["doubts"]
    assert client.get("/api/admin/overview", headers=student).status_code == 403


def test_gateway_health_and_unknown_routes(client):
    h = client.get("/api/health")
    assert h.status_code == 200 and h.json()["services"] == {"auth": "ok", "grievance": "ok", "notification": "ok", "admin": "ok", "doubt": "ok"}
    assert client.get("/api/nothing-here").status_code == 404


def test_gateway_serves_frontend_and_request_id(client):
    r = client.get("/")
    assert r.status_code == 200 and "text/html" in r.headers["content-type"]
    assert client.get("/api/health", headers={"X-Request-ID": "abc123"}).headers["X-Request-ID"] == "abc123"


def test_rate_limiter_unit():
    limiter = SlidingWindowLimiter(limit=3, window_seconds=60)
    assert [limiter.allow("ip") for _ in range(4)] == [True, True, True, False]
    assert limiter.allow("other-ip")


def test_upstream_down_returns_503(client, student):
    import httpx
    original = client.app.state.clients["notification"]
    client.app.state.clients["notification"] = httpx.AsyncClient(base_url="http://127.0.0.1:9", timeout=1)
    try:
        r = client.get("/api/notifications", headers=student)
        assert r.status_code == 503 and "unavailable" in r.json()["error"]
    finally:
        client.app.state.clients["notification"] = original


def test_classifier_unit():
    from services.grievance_service.classifier import classify
    c = classify("Exam results delayed, marks not uploaded", ["Examination", "Hostel"])
    assert c.category == "Examination" and c.priority == "High"
    assert classify("random words", ["Academic"]).confidence == 0.0
    assert classify("There is a fire in the lab", None).priority == "Urgent"
