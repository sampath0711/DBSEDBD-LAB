"""Academic doubts: students ask, faculty answer, either side can resolve; events fan out as notifications."""


def _ask(client, headers, **kw):
    body = {"subject": "Database Systems", "title": "What is a covering index?",
            "description": "I keep seeing 'covering index' in query plans. What does it mean and when is it useful?", **kw}
    r = client.post("/api/doubts", json=body, headers=headers)
    assert r.status_code == 201, r.text
    return r.json()


def _notes(client, headers, **params):
    return client.get("/api/notifications", params=params, headers=headers).json()


def test_seed_data_and_contract(client, student):
    rows = client.get("/api/doubts", headers=student).json()
    assert {"Resolved", "Answered"} <= {d["status"] for d in rows}
    d = rows[0]
    for k in ("id", "code", "subject", "title", "description", "status", "asked_by_name", "reply_count", "created_at"):
        assert k in d
    assert d["replies"] is None                                   # replies only on the detail endpoint
    detail = client.get(f"/api/doubts/{d['id']}", headers=student).json()
    assert isinstance(detail["replies"], list)


def test_only_students_can_ask(client, student, faculty, hostel_staff, admin):
    assert _ask(client, student)["status"] == "Open"
    for who in (faculty, hostel_staff, admin):
        body = {"subject": "Maths", "title": "A question", "description": "Some long enough description here."}
        assert client.post("/api/doubts", json=body, headers=who).status_code == 403


def test_validation(client, student):
    assert client.post("/api/doubts", json={"subject": "x"}, headers=student).status_code == 422
    assert client.post("/api/doubts", json={"subject": "Maths", "title": "ok title", "description": "short"}, headers=student).status_code == 422


def test_codes_are_unique(client, student):
    assert len({_ask(client, student)["code"] for _ in range(4)}) == 4


def test_visibility_rules(client, student, student2, faculty, hostel_staff, admin):
    mine = _ask(client, student)
    assert client.get(f"/api/doubts/{mine['id']}", headers=student).status_code == 200
    assert client.get(f"/api/doubts/{mine['id']}", headers=student2).status_code == 403
    assert client.get(f"/api/doubts/{mine['id']}", headers=faculty).status_code == 200
    assert client.get(f"/api/doubts/{mine['id']}", headers=admin).status_code == 200
    assert client.get(f"/api/doubts/{mine['id']}", headers=hostel_staff).status_code == 403          # staff are not part of Q&A
    assert client.get("/api/doubts", headers=hostel_staff).status_code == 403
    assert client.get("/api/doubts/999999", headers=faculty).status_code == 404
    assert mine["id"] not in {d["id"] for d in client.get("/api/doubts", headers=student2).json()}
    assert mine["id"] in {d["id"] for d in client.get("/api/doubts", headers=faculty).json()}


def test_full_conversation_lifecycle(client, student, faculty):
    d = _ask(client, student)
    # faculty answers -> Answered
    r = client.post(f"/api/doubts/{d['id']}/replies", json={"body": "A covering index contains every column the query needs."}, headers=faculty)
    assert r.status_code == 201
    body = r.json()
    assert body["status"] == "Answered" and body["answered_by_name"] == "Ramesh Iyer" and body["reply_count"] == 1
    assert body["replies"][0]["author_role"] == "faculty"
    # student follow-up -> back to Open
    r = client.post(f"/api/doubts/{d['id']}/replies", json={"body": "So the table itself is never read?"}, headers=student)
    assert r.json()["status"] == "Open" and r.json()["reply_count"] == 2
    # faculty answers again, then student resolves
    client.post(f"/api/doubts/{d['id']}/replies", json={"body": "Correct — an index-only scan."}, headers=faculty)
    r = client.patch(f"/api/doubts/{d['id']}", json={"status": "Resolved"}, headers=student)
    assert r.json()["status"] == "Resolved"
    # no more replies once resolved, until the student reopens
    assert client.post(f"/api/doubts/{d['id']}/replies", json={"body": "one more thing"}, headers=student).status_code == 409
    assert client.patch(f"/api/doubts/{d['id']}", json={"status": "Open"}, headers=faculty).status_code == 403   # faculty cannot reopen
    assert client.patch(f"/api/doubts/{d['id']}", json={"status": "Open"}, headers=student).json()["status"] == "Open"
    assert [x["author_role"] for x in client.get(f"/api/doubts/{d['id']}", headers=student).json()["replies"]] == ["faculty", "student", "faculty"]


def test_reply_permissions(client, student, student2, faculty, admin):
    d = _ask(client, student)
    assert client.post(f"/api/doubts/{d['id']}/replies", json={"body": "hi"}, headers=student2).status_code == 403   # another student
    assert client.post(f"/api/doubts/{d['id']}/replies", json={"body": "hi"}, headers=admin).status_code == 403      # admin is read-only
    assert client.patch(f"/api/doubts/{d['id']}", json={"status": "Resolved"}, headers=student2).status_code == 403
    assert client.patch(f"/api/doubts/{d['id']}", json={"status": "Answered"}, headers=faculty).status_code == 422
    assert client.post(f"/api/doubts/{d['id']}/replies", json={"body": ""}, headers=faculty).status_code == 422


def test_faculty_can_resolve_directly(client, student, faculty):
    d = _ask(client, student)
    assert client.patch(f"/api/doubts/{d['id']}", json={"status": "Resolved"}, headers=faculty).json()["status"] == "Resolved"


def test_filters_stats_and_subjects(client, student, faculty):
    d = _ask(client, student, subject="Compiler Design", title="What is left recursion?")
    assert "Compiler Design" in client.get("/api/doubts/subjects", headers=faculty).json()
    rows = client.get("/api/doubts", params={"subject": "compiler design"}, headers=faculty).json()      # case-insensitive
    assert rows and all(r["subject"] == "Compiler Design" for r in rows)
    assert all(r["status"] == "Open" for r in client.get("/api/doubts?status=Open", headers=faculty).json())
    client.post(f"/api/doubts/{d['id']}/replies", json={"body": "Left recursion is when A → Aα."}, headers=faculty)
    mine = client.get("/api/doubts?answered_by_me=true", headers=faculty).json()
    assert d["id"] in {r["id"] for r in mine}
    s = client.get("/api/doubts/stats", headers=faculty).json()
    assert s["total"] == s["open"] + s["answered"] + s["resolved"] and s["mine"] >= 1
    st = client.get("/api/doubts/stats", headers=student).json()
    assert st["total"] == st["open"] + st["answered"] + st["resolved"]


def test_notifications_flow_between_student_and_faculty(client, student2, faculty):
    d = _ask(client, student2, title="Why is quicksort O(n^2) worst case?")
    # all faculty are told about a new doubt; the asker is not
    assert any(d["code"] in n["message"] and "New doubt" in n["message"] for n in _notes(client, faculty))
    assert not any(d["code"] in n["message"] for n in _notes(client, student2))
    # faculty answers -> student is notified
    client.post(f"/api/doubts/{d['id']}/replies", json={"body": "Pick the smallest element as pivot on sorted input."}, headers=faculty)
    assert any(d["code"] in n["message"] and "answered your doubt" in n["message"] for n in _notes(client, student2))
    # student follow-up goes to the faculty member who answered (not broadcast)
    client.post(f"/api/doubts/{d['id']}/replies", json={"body": "How do random pivots help?"}, headers=student2)
    assert any(d["code"] in n["message"] and "follow-up" in n["message"] for n in _notes(client, faculty))
    # student resolves -> responder notified; own actions never notify yourself
    before = len(_notes(client, student2))
    client.patch(f"/api/doubts/{d['id']}", json={"status": "Resolved"}, headers=student2)
    assert any("marked" in n["message"] and d["code"] in n["message"] for n in _notes(client, faculty))
    assert len(_notes(client, student2)) == before


def test_faculty_broadcast_read_state_is_per_user(client, student, faculty):
    """A new faculty member registered via the API also sees broadcast doubt notices, with independent read state."""
    reg = client.post("/api/auth/register", json={"name": "Dr. Second", "email": "dr.second@campus.edu", "password": "s3cretpass",
                                                   "role": "faculty", "department": "Mathematics", "faculty_code": "FACULTY-2026"})
    second = {"Authorization": f"Bearer {reg.json()['token']}"}
    d = _ask(client, student, title="Is every continuous function differentiable?")
    msg = next(n for n in _notes(client, second) if d["code"] in n["message"])
    assert msg["read"] is False
    client.post(f"/api/notifications/{msg['id']}/read", headers=second)
    first_view = next(n for n in _notes(client, faculty) if d["code"] in n["message"])
    assert first_view["read"] is False                           # other faculty member still sees it unread


def test_new_faculty_can_answer_doubts(client, student):
    reg = client.post("/api/auth/register", json={"name": "Dr. Third", "email": "dr.third@campus.edu", "password": "s3cretpass",
                                                   "role": "faculty", "department": "Physics", "faculty_code": "FACULTY-2026"})
    third = {"Authorization": f"Bearer {reg.json()['token']}"}
    d = _ask(client, student, subject="Physics", title="What is the photoelectric effect?")
    r = client.post(f"/api/doubts/{d['id']}/replies", json={"body": "Electrons are emitted when light exceeds a threshold frequency."}, headers=third)
    assert r.status_code == 201 and r.json()["answered_by_name"] == "Dr. Third"
