"""Kafka-style event flow: grievance-service publishes, notification-service consumes (in-memory bus here)."""
import asyncio

from services.notification_service import handlers


def _notes(client, headers, **params):
    return client.get("/api/notifications", params=params, headers=headers).json()


def _create(client, headers, **kw):
    body = {"title": "Broken bench in seminar hall", "description": "Several benches in the seminar hall are broken and unsafe to sit on.",
            "category": "Hostel", "priority": "Urgent", **kw}
    return client.post("/api/grievances", json=body, headers=headers).json()


def test_create_notifies_submitter_department_and_admin(client, student2, hostel_staff, registrar_staff, admin):
    g = _create(client, student2)
    assert any(g["case_code"] in n["message"] and "submitted" in n["message"] for n in _notes(client, student2))
    assert any(g["case_code"] in n["message"] for n in _notes(client, hostel_staff))
    assert not any(g["case_code"] in n["message"] for n in _notes(client, registrar_staff))
    assert any("Urgent" in n["message"] and g["case_code"] in n["message"] for n in _notes(client, admin))


def test_status_change_notifies_complainant(client, student2, hostel_staff):
    g = _create(client, student2)
    client.patch(f"/api/grievances/{g['id']}", json={"status": "Resolved", "note": "Benches replaced."}, headers=hostel_staff)
    msgs = [n["message"] for n in _notes(client, student2)]
    assert any(g["case_code"] in m and "from Submitted to Resolved" in m for m in msgs)
    assert any("New update on" in m and "Benches replaced." in m for m in msgs)


def test_actor_is_not_notified_of_own_action(client, student2, hostel_staff):
    g = _create(client, student2)
    before = len(_notes(client, student2))
    client.post(f"/api/grievances/{g['id']}/comments", json={"text": "adding detail"}, headers=student2)
    assert len(_notes(client, student2)) == before                      # own comment -> no self-notification
    assert any("complainant commented" in n["message"] for n in _notes(client, hostel_staff))


def test_read_state_is_per_user(client, student2, hostel_staff):
    _create(client, student2)
    unread = client.get("/api/notifications/unread-count", headers=hostel_staff).json()["unread"]
    assert unread >= 1
    first = _notes(client, hostel_staff, unread_only=True)[0]
    assert client.post(f"/api/notifications/{first['id']}/read", headers=hostel_staff).json()["read"] is True
    assert client.get("/api/notifications/unread-count", headers=hostel_staff).json()["unread"] == unread - 1
    # another user cannot touch it
    assert client.post(f"/api/notifications/{first['id']}/read", headers=student2).status_code == 404
    assert client.post("/api/notifications/not-an-id/read", headers=hostel_staff).status_code == 404
    assert client.post("/api/notifications/read-all", headers=hostel_staff).json() == {"unread": 0}


def test_welcome_notification_on_register(client):
    r = client.post("/api/auth/register", json={"name": "Fresh Face", "email": "fresh@campus.edu", "password": "s3cretpass"})
    headers = {"Authorization": f"Bearer {r.json()['token']}"}
    assert any("Welcome, Fresh Face" in n["message"] for n in _notes(client, headers))


def test_duplicate_kafka_delivery_is_idempotent(client, student2):
    g = _create(client, student2)
    event = {"event_id": "dup-1", "type": "grievance.updated", "occurred_at": "2026-01-01T00:00:00Z",
             "data": {"id": g["id"], "case_code": g["case_code"], "title": "t", "category": "Hostel", "priority": "Urgent",
                      "status": "Closed", "old_status": "Submitted", "department": g["department"], "old_department": g["department"],
                      "submitted_by": 2, "actor_id": 99, "actor_name": "Someone"}}
    before = len(_notes(client, student2))

    async def deliver_twice():
        await handlers.handle_grievance_event(event)
        await handlers.handle_grievance_event(event)

    client.portal.call(deliver_twice)
    assert len(_notes(client, student2)) == before + 1
