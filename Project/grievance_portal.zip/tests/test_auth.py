def test_login_success_returns_token_and_user(client):
    r = client.post("/api/auth/login", json={"email": "ananya.rao@campus.edu", "password": "password123"})
    assert r.status_code == 200
    body = r.json()
    assert body["token"] and body["user"] == {"id": 1, "name": "Ananya Rao", "role": "student", "department": None}


def test_login_is_case_insensitive_on_email(client):
    r = client.post("/api/auth/login", json={"email": "  ANANYA.RAO@campus.edu ", "password": "password123"})
    assert r.status_code == 200


def test_wrong_password_and_unknown_user_give_same_error(client):
    a = client.post("/api/auth/login", json={"email": "ananya.rao@campus.edu", "password": "nope"})
    b = client.post("/api/auth/login", json={"email": "ghost@campus.edu", "password": "nope"})
    assert a.status_code == b.status_code == 401
    assert a.json() == b.json() == {"error": "Invalid email or password."}


def test_register_creates_student_and_logs_in(client):
    r = client.post("/api/auth/register", json={"name": "New Student", "email": "new.student@campus.edu", "password": "s3cretpass"})
    assert r.status_code == 201
    token = r.json()["token"]
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200 and me.json()["role"] == "student"


def test_register_cannot_self_assign_admin(client):
    r = client.post("/api/auth/register", json={"name": "Sneaky", "email": "sneaky@campus.edu", "password": "s3cretpass", "role": "admin"})
    assert r.status_code == 422


def test_duplicate_email_conflicts(client):
    r = client.post("/api/auth/register", json={"name": "Dup", "email": "ananya.rao@campus.edu", "password": "s3cretpass"})
    assert r.status_code == 409


def test_missing_and_bad_tokens_are_rejected(client):
    assert client.get("/api/grievances").status_code == 401
    assert client.get("/api/grievances", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_only_admin_can_list_or_create_users(client, student, admin):
    assert client.get("/api/auth/users", headers=student).status_code == 403
    assert len(client.get("/api/auth/users", headers=admin).json()) >= 6
    payload = {"name": "Lib Staff", "email": "lib.staff@campus.edu", "password": "s3cretpass", "role": "staff"}
    assert client.post("/api/auth/users", json=payload, headers=admin).status_code == 422  # staff need a department
    ok = client.post("/api/auth/users", json={**payload, "department": "Library"}, headers=admin)
    assert ok.status_code == 201 and ok.json()["department"] == "Library"


def test_internal_endpoints_are_not_reachable_through_gateway(client, admin):
    assert client.get("/api/internal/users/summary", headers=admin).status_code == 404


# ----------------------------------------------------------------- registration (student + faculty)
FACULTY = {"name": "Dr. New Faculty", "email": "dr.new@campus.edu", "password": "s3cretpass", "role": "faculty",
           "department": "Computer Science", "faculty_code": "FACULTY-2026"}


def test_faculty_registration_requires_valid_code(client):
    no_code = {k: v for k, v in FACULTY.items() if k != "faculty_code"}
    assert client.post("/api/auth/register", json=no_code).status_code == 403
    r = client.post("/api/auth/register", json={**FACULTY, "faculty_code": "WRONG"})
    assert r.status_code == 403 and r.json()["error"] == "Invalid faculty registration code."


def test_faculty_registration_requires_department(client):
    r = client.post("/api/auth/register", json={**FACULTY, "department": "  "})
    assert r.status_code == 422 and "department" in r.json()["error"].lower()


def test_faculty_can_register_with_code_and_gets_department(client):
    r = client.post("/api/auth/register", json=FACULTY)
    assert r.status_code == 201
    assert r.json()["user"]["role"] == "faculty" and r.json()["user"]["department"] == "Computer Science"
    # and can log in with it afterwards
    assert client.post("/api/auth/login", json={"email": FACULTY["email"], "password": "s3cretpass"}).status_code == 200


def test_student_registration_ignores_department_and_code(client):
    r = client.post("/api/auth/register", json={"name": "Stu Dent", "email": "stu.dent@campus.edu", "password": "s3cretpass",
                                                 "department": "Physics", "faculty_code": "irrelevant"})
    assert r.status_code == 201 and r.json()["user"]["role"] == "student" and r.json()["user"]["department"] is None


def test_registration_validation(client):
    base = {"name": "Val Id", "email": "val.id@campus.edu", "password": "s3cretpass"}
    assert client.post("/api/auth/register", json={**base, "password": "short"}).status_code == 422
    assert client.post("/api/auth/register", json={**base, "email": "not-an-email"}).status_code == 422
    assert client.post("/api/auth/register", json={**base, "role": "staff"}).status_code == 422
