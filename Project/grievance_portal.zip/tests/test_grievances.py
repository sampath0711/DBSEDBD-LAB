def _create(client, headers, **overrides):
    body = {"title": "Projector not working in Lab 7", "description": "The ceiling projector in Lab 7 has not powered on for a week.",
            "category": "Infrastructure", "priority": "High", **overrides}
    r = client.post("/api/grievances", json=body, headers=headers)
    assert r.status_code == 201, r.text
    return r.json()


def test_seeded_data_visible_with_frontend_contract(client, student):
    rows = client.get("/api/grievances", headers=student).json()
    assert {g["case_code"] for g in rows} >= {"GRC-091", "GRC-095"}
    g = rows[0]
    for key in ("id", "case_code", "title", "category", "priority", "status", "department", "submitted_by_name", "created_at", "timeline"):
        assert key in g
    assert g["timeline"] and set(g["timeline"][0]) == {"when", "what"}


def test_create_routes_to_department_and_writes_timeline(client, student):
    g = _create(client, student)
    assert g["status"] == "Submitted" and g["department"] == "Facilities & Maintenance"
    assert g["case_code"].startswith("GRC-") and g["submitted_by_name"] == "Ananya Rao"
    texts = [t["what"] for t in g["timeline"]]
    assert texts[0] == "Grievance submitted by complainant." and "routed to Facilities & Maintenance" in texts[1]


def test_case_codes_are_unique(client, student):
    codes = {_create(client, student)["case_code"] for _ in range(4)}
    assert len(codes) == 4


def test_auto_classification_when_category_omitted(client, student):
    g = _create(client, student, title="Hostel mess food unsafe", description="The mess serves undercooked food and a student fell ill, it is a health hazard.",
                category=None, priority=None)
    assert g["category"] == "Hostel" and g["department"] == "Hostel Administration"
    assert g["priority"] == "Urgent"
    assert g["classification"]["suggested_category"] == "Hostel" and g["classification"]["matched_keywords"]
    assert "Auto-categorized" in g["timeline"][1]["what"]


def test_validation_and_unknown_category(client, student):
    assert client.post("/api/grievances", json={"title": "x"}, headers=student).status_code == 422
    r = client.post("/api/grievances", json={"title": "Valid title", "description": "A sufficiently long description.", "category": "Nope"}, headers=student)
    assert r.status_code == 400 and r.json()["error"] == "Unknown category."


def test_visibility_scoping(client, student, student2, hostel_staff, registrar_staff, admin):
    mine = _create(client, student)                                       # Facilities & Maintenance
    assert client.get(f"/api/grievances/{mine['id']}", headers=student).status_code == 200
    assert client.get(f"/api/grievances/{mine['id']}", headers=student2).status_code == 403
    assert client.get(f"/api/grievances/{mine['id']}", headers=hostel_staff).status_code == 403
    assert client.get(f"/api/grievances/{mine['id']}", headers=admin).status_code == 200
    ids_student2 = {g["id"] for g in client.get("/api/grievances", headers=student2).json()}
    assert mine["id"] not in ids_student2
    hostel_rows = client.get("/api/grievances", headers=hostel_staff).json()
    assert hostel_rows and all(g["department"] == "Hostel Administration" or g["submitted_by_name"] == "Divya Kumar" for g in hostel_rows)
    assert client.get("/api/grievances/999999", headers=admin).status_code == 404


def test_filters(client, admin):
    rows = client.get("/api/grievances?status=Closed", headers=admin).json()
    assert rows and all(g["status"] == "Closed" for g in rows)
    rows = client.get("/api/grievances?category=Hostel&priority=Urgent", headers=admin).json()
    assert rows and all(g["category"] == "Hostel" and g["priority"] == "Urgent" for g in rows)
    assert client.get("/api/grievances?status=Bogus", headers=admin).status_code == 422


def test_staff_can_update_own_department_only(client, student, hostel_staff, registrar_staff, admin):
    g = _create(client, student, title="Mess hygiene issue", description="Cockroaches found in the mess kitchen last night.", category="Hostel")
    assert g["department"] == "Hostel Administration"
    r = client.patch(f"/api/grievances/{g['id']}", json={"status": "In Progress", "note": "Pest control booked."}, headers=hostel_staff)
    assert r.status_code == 200 and r.json()["status"] == "In Progress"
    assert "Status changed to In Progress." in r.json()["timeline"][-1]["what"] and "Pest control booked." in r.json()["timeline"][-1]["what"]
    assert client.patch(f"/api/grievances/{g['id']}", json={"status": "Resolved"}, headers=registrar_staff).status_code == 403
    assert client.patch(f"/api/grievances/{g['id']}", json={"status": "Resolved"}, headers=student).status_code == 403
    assert client.patch(f"/api/grievances/{g['id']}", json={"status": "Bogus"}, headers=admin).status_code == 422
    r = client.patch(f"/api/grievances/{g['id']}", json={"department": "Facilities & Maintenance", "assigned_to": "Mr. Rao"}, headers=admin)
    assert r.json()["department"] == "Facilities & Maintenance" and r.json()["assigned_to"] == "Mr. Rao"


def test_stats_are_scoped(client, student2, admin):
    s = client.get("/api/grievances/stats", headers=student2).json()
    assert set(s) == {"total", "open", "resolved", "urgent"} and s["total"] >= 1
    a = client.get("/api/grievances/stats", headers=admin).json()
    assert a["total"] >= s["total"] and a["total"] == a["open"] + a["resolved"]


def test_comments_extend_timeline_and_respect_access(client, student, student2):
    g = _create(client, student)
    r = client.post(f"/api/grievances/{g['id']}/comments", json={"text": "Any update on this?"}, headers=student)
    assert r.status_code == 201 and r.json()["timeline"][-1]["what"].endswith("Any update on this?")
    assert client.post(f"/api/grievances/{g['id']}/comments", json={"text": "hi"}, headers=student2).status_code == 403


def test_similar_case_search(client, student, admin):
    _create(client, student, title="Wifi router down in library", description="The library wifi router has been offline for three days.", category="Infrastructure")
    hits = client.get("/api/grievances/search", params={"q": "library wifi offline"}, headers=admin).json()
    assert hits and "wifi" in hits[0]["title"].lower() and 0 < hits[0]["score"] <= 1
    assert client.get("/api/grievances/search", params={"q": "zzzz qqqq"}, headers=admin).json() == []
    first = hits[0]["id"]
    twin = _create(client, student, title="Library wifi router offline", description="Wifi router in the library is offline again, three days now.", category="Infrastructure")
    similar = client.get(f"/api/grievances/{twin['id']}/similar", headers=admin).json()
    assert first in [s["id"] for s in similar] and twin["id"] not in [s["id"] for s in similar]


def test_search_never_leaks_other_users_cases(client, student, student2):
    _create(client, student, title="Confidential scholarship dispute", description="Scholarship amount wrongly deducted from my account.", category="Administrative")
    assert client.get("/api/grievances/search", params={"q": "scholarship dispute deducted"}, headers=student2).json() == []
