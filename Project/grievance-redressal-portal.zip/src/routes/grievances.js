const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const STATUS_FLOW = ['Submitted', 'Under Review', 'In Progress', 'Resolved', 'Closed'];
const PRIORITIES = ['Routine', 'High', 'Urgent'];

async function nextCaseCode() {
  const [rows] = await pool.query(
    "SELECT case_code FROM grievances ORDER BY id DESC LIMIT 1"
  );
  let next = 100;
  if (rows.length) {
    const n = parseInt(rows[0].case_code.split('-')[1], 10);
    if (!isNaN(n)) next = n + 1;
  }
  return `GRC-${next}`;
}

async function attachTimelines(grievances) {
  if (grievances.length === 0) return grievances;
  const ids = grievances.map(g => g.id);
  const [timelineRows] = await pool.query(
    `SELECT * FROM grievance_timeline WHERE grievance_id IN (?) ORDER BY created_at ASC, id ASC`,
    [ids]
  );
  const byGrievance = {};
  timelineRows.forEach(t => {
    (byGrievance[t.grievance_id] = byGrievance[t.grievance_id] || []).push({
      when: t.created_at,
      what: t.event_text
    });
  });
  return grievances.map(g => ({ ...g, timeline: byGrievance[g.id] || [] }));
}

// GET /api/grievances?status=&category=
router.get('/', async (req, res) => {
  const { status, category } = req.query;
  const { role, id: userId, department } = req.user;

  let sql = `SELECT g.*, u.name AS submitted_by_name FROM grievances g
             JOIN users u ON u.id = g.submitted_by WHERE 1=1`;
  const params = [];

  if (role === 'admin') {
    // sees everything
  } else if (role === 'staff') {
    sql += ' AND (g.department = ? OR g.submitted_by = ?)';
    params.push(department, userId);
  } else {
    sql += ' AND g.submitted_by = ?';
    params.push(userId);
  }

  if (status) { sql += ' AND g.status = ?'; params.push(status); }
  if (category) { sql += ' AND g.category = ?'; params.push(category); }

  sql += ' ORDER BY g.created_at DESC';

  try {
    const [rows] = await pool.query(sql, params);
    const withTimelines = await attachTimelines(rows);
    res.json(withTimelines);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load grievances.' });
  }
});

// GET /api/grievances/stats
router.get('/stats', async (req, res) => {
  const { role, id: userId, department } = req.user;
  let scopeSql = '1=1';
  const params = [];

  if (role === 'admin') {
    // no restriction
  } else if (role === 'staff') {
    scopeSql = '(department = ? OR submitted_by = ?)';
    params.push(department, userId);
  } else {
    scopeSql = 'submitted_by = ?';
    params.push(userId);
  }

  try {
    const [[totals]] = await pool.query(
      `SELECT COUNT(*) AS total FROM grievances WHERE ${scopeSql}`, params
    );
    const [[open]] = await pool.query(
      `SELECT COUNT(*) AS open FROM grievances WHERE ${scopeSql} AND status NOT IN ('Resolved','Closed')`, params
    );
    const [[resolved]] = await pool.query(
      `SELECT COUNT(*) AS resolved FROM grievances WHERE ${scopeSql} AND status IN ('Resolved','Closed')`, params
    );
    const [[urgent]] = await pool.query(
      `SELECT COUNT(*) AS urgent FROM grievances WHERE ${scopeSql} AND priority='Urgent' AND status NOT IN ('Resolved','Closed')`, params
    );
    res.json({
      total: totals.total, open: open.open, resolved: resolved.resolved, urgent: urgent.urgent
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load dashboard stats.' });
  }
});

// GET /api/grievances/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT g.*, u.name AS submitted_by_name FROM grievances g
       JOIN users u ON u.id = g.submitted_by WHERE g.id = ?`,
      [req.params.id]
    );
    const grievance = rows[0];
    if (!grievance) return res.status(404).json({ error: 'Case not found.' });

    const { role, id: userId, department } = req.user;
    const canView = role === 'admin' ||
      grievance.submitted_by === userId ||
      (role === 'staff' && grievance.department === department);
    if (!canView) return res.status(403).json({ error: 'You do not have access to this case.' });

    const [withTimeline] = await attachTimelines([grievance]);
    res.json(withTimeline);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load this case.' });
  }
});

// POST /api/grievances
router.post('/', async (req, res) => {
  const { title, description, category, priority } = req.body;
  if (!title || !description || !category) {
    return res.status(400).json({ error: 'Title, description, and category are required.' });
  }

  try {
    const [catRows] = await pool.query('SELECT default_department FROM categories WHERE name = ?', [category]);
    if (!catRows.length) return res.status(400).json({ error: 'Unknown category.' });
    const department = catRows[0].default_department;
    const finalPriority = PRIORITIES.includes(priority) ? priority : 'Routine';
    const caseCode = await nextCaseCode();

    const [result] = await pool.query(
      `INSERT INTO grievances (case_code, title, description, category, priority, status, department, submitted_by)
       VALUES (?, ?, ?, ?, ?, 'Submitted', ?, ?)`,
      [caseCode, title, description, category, finalPriority, department, req.user.id]
    );
    const grievanceId = result.insertId;

    await pool.query(
      'INSERT INTO grievance_timeline (grievance_id, event_text) VALUES (?, ?)',
      [grievanceId, 'Grievance submitted by complainant.']
    );
    await pool.query(
      'INSERT INTO grievance_timeline (grievance_id, event_text) VALUES (?, ?)',
      [grievanceId, `Auto-categorized as ${category} · ${finalPriority}, routed to ${department}.`]
    );

    const [rows] = await pool.query(
      `SELECT g.*, u.name AS submitted_by_name FROM grievances g
       JOIN users u ON u.id = g.submitted_by WHERE g.id = ?`,
      [grievanceId]
    );
    const [withTimeline] = await attachTimelines(rows);
    res.status(201).json(withTimeline);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not submit grievance.' });
  }
});

// PATCH /api/grievances/:id  (admin, or staff for their own department)
router.patch('/:id', requireRole('admin', 'staff'), async (req, res) => {
  const { status, department, note } = req.body;

  try {
    const [rows] = await pool.query('SELECT * FROM grievances WHERE id = ?', [req.params.id]);
    const grievance = rows[0];
    if (!grievance) return res.status(404).json({ error: 'Case not found.' });

    if (req.user.role === 'staff' && grievance.department !== req.user.department) {
      return res.status(403).json({ error: 'You can only update cases routed to your department.' });
    }
    if (status && !STATUS_FLOW.includes(status)) {
      return res.status(400).json({ error: 'Invalid status value.' });
    }

    const newStatus = status || grievance.status;
    const newDepartment = department || grievance.department;

    await pool.query(
      'UPDATE grievances SET status = ?, department = ? WHERE id = ?',
      [newStatus, newDepartment, req.params.id]
    );

    let entry = '';
    if (newStatus !== grievance.status) entry += `Status changed to ${newStatus}. `;
    if (newDepartment !== grievance.department) entry += `Reassigned to ${newDepartment}. `;
    if (note && note.trim()) entry += note.trim();
    if (!entry) entry = 'Case reviewed, no change.';

    await pool.query(
      'INSERT INTO grievance_timeline (grievance_id, event_text) VALUES (?, ?)',
      [req.params.id, entry.trim()]
    );

    const [updatedRows] = await pool.query(
      `SELECT g.*, u.name AS submitted_by_name FROM grievances g
       JOIN users u ON u.id = g.submitted_by WHERE g.id = ?`,
      [req.params.id]
    );
    const [withTimeline] = await attachTimelines(updatedRows);
    res.json(withTimeline);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not update this case.' });
  }
});

module.exports = router;
