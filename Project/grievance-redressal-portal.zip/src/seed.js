require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('./db');

const CATEGORIES = [
  { name: 'Academic', default_department: 'Academic Affairs Office' },
  { name: 'Examination', default_department: 'Controller of Examinations' },
  { name: 'Infrastructure', default_department: 'Facilities & Maintenance' },
  { name: 'Hostel', default_department: 'Hostel Administration' },
  { name: 'Administrative', default_department: "Registrar's Office" }
];

const DEMO_PASSWORD = 'password123';

const USERS = [
  { name: 'Ananya Rao',   email: 'ananya.rao@campus.edu',   role: 'student', department: null },
  { name: 'Karthik Nair', email: 'karthik.nair@campus.edu', role: 'student', department: null },
  { name: 'Ramesh Iyer',  email: 'ramesh.iyer@campus.edu',  role: 'faculty', department: 'Academic Affairs Office' },
  { name: 'Priya Menon',  email: 'priya.menon@campus.edu',  role: 'staff',   department: "Registrar's Office" },
  { name: 'Divya Kumar',  email: 'divya.kumar@campus.edu',  role: 'staff',   department: 'Hostel Administration' },
  { name: 'Admin User',   email: 'admin@campus.edu',        role: 'admin',   department: null }
];

function daysAgoDate(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

async function main() {
  console.log('Seeding categories...');
  for (const c of CATEGORIES) {
    await pool.query(
      'INSERT INTO categories (name, default_department) VALUES (?, ?) ON DUPLICATE KEY UPDATE default_department = VALUES(default_department)',
      [c.name, c.default_department]
    );
  }

  console.log('Seeding users...');
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const userIds = {};
  for (const u of USERS) {
    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [u.email]);
    if (existing.length) {
      userIds[u.name] = existing[0].id;
      continue;
    }
    const [result] = await pool.query(
      'INSERT INTO users (name, email, password_hash, role, department) VALUES (?, ?, ?, ?, ?)',
      [u.name, u.email, passwordHash, u.role, u.department]
    );
    userIds[u.name] = result.insertId;
  }

  console.log('Seeding grievances...');
  const [existingGrievances] = await pool.query('SELECT COUNT(*) as count FROM grievances');
  if (existingGrievances[0].count > 0) {
    console.log('Grievances already exist, skipping grievance seed.');
  } else {
    const grievances = [
      {
        case_code: 'GRC-091', title: 'Mess food quality complaint', category: 'Hostel', priority: 'High',
        status: 'In Progress', submittedBy: 'Ananya Rao', department: 'Hostel Administration', daysAgo: 6,
        description: 'Repeated instances of undercooked food in Block C mess over the past two weeks, with no response from the mess committee.',
        timeline: [
          { daysAgo: 6, text: 'Grievance submitted by complainant.' },
          { daysAgo: 5, text: 'Auto-categorized as Hostel · High priority, routed to Hostel Administration.' },
          { daysAgo: 3, text: 'Assigned to Hostel Warden for inspection.' },
          { daysAgo: 1, text: 'Site inspection completed, corrective action in progress.' }
        ]
      },
      {
        case_code: 'GRC-095', title: 'Delay in semester grade upload', category: 'Examination', priority: 'Routine',
        status: 'Under Review', submittedBy: 'Ananya Rao', department: 'Controller of Examinations', daysAgo: 4,
        description: 'Grades for the Database Systems course have not been uploaded three weeks after the exam, delaying scholarship processing.',
        timeline: [
          { daysAgo: 4, text: 'Grievance submitted by complainant.' },
          { daysAgo: 3, text: 'Auto-categorized as Examination · Routine, routed to Controller of Examinations.' },
          { daysAgo: 1, text: 'Under review by examination cell.' }
        ]
      },
      {
        case_code: 'GRC-101', title: 'Broken projector in Lab 4', category: 'Infrastructure', priority: 'Routine',
        status: 'Resolved', submittedBy: 'Ramesh Iyer', department: 'Facilities & Maintenance', daysAgo: 12,
        description: 'Ceiling projector in Lab 4 has not powered on for two weeks, affecting scheduled practical sessions.',
        timeline: [
          { daysAgo: 12, text: 'Grievance submitted by complainant.' },
          { daysAgo: 11, text: 'Routed to Facilities & Maintenance.' },
          { daysAgo: 9, text: 'Technician dispatched.' },
          { daysAgo: 7, text: 'Projector replaced and tested. Marked resolved.' }
        ]
      },
      {
        case_code: 'GRC-104', title: 'Incorrect fee deduction on portal', category: 'Administrative', priority: 'Urgent',
        status: 'Submitted', submittedBy: 'Priya Menon', department: "Registrar's Office", daysAgo: 1,
        description: 'Payroll portal shows a duplicate deduction for August salary, causing a mismatch with the payslip.',
        timeline: [
          { daysAgo: 1, text: 'Grievance submitted by complainant.' },
          { daysAgo: 1, text: "Auto-categorized as Administrative · Urgent, routed to Registrar's Office." }
        ]
      },
      {
        case_code: 'GRC-106', title: 'Water leakage in hostel corridor', category: 'Hostel', priority: 'Urgent',
        status: 'Under Review', submittedBy: 'Karthik Nair', department: 'Hostel Administration', daysAgo: 2,
        description: 'Persistent water leakage in the second-floor corridor of Block A, creating a slip hazard near the stairwell.',
        timeline: [
          { daysAgo: 2, text: 'Grievance submitted by complainant.' },
          { daysAgo: 2, text: 'Flagged Urgent by automated triage, routed to Hostel Administration.' },
          { daysAgo: 1, text: 'Maintenance team notified, inspection scheduled.' }
        ]
      },
      {
        case_code: 'GRC-108', title: 'Elective allotment discrepancy', category: 'Academic', priority: 'High',
        status: 'Closed', submittedBy: 'Ramesh Iyer', department: 'Academic Affairs Office', daysAgo: 20,
        description: 'Two students were allotted to an elective section that had already reached capacity, exceeding the classroom limit.',
        timeline: [
          { daysAgo: 20, text: 'Grievance submitted by complainant.' },
          { daysAgo: 19, text: 'Routed to Academic Affairs Office.' },
          { daysAgo: 16, text: 'Section capacity corrected, students reassigned.' },
          { daysAgo: 15, text: 'Confirmed resolved by complainant. Case closed.' }
        ]
      }
    ];

    for (const g of grievances) {
      const submitterId = userIds[g.submittedBy];
      const createdAt = daysAgoDate(g.daysAgo);
      const [result] = await pool.query(
        `INSERT INTO grievances (case_code, title, description, category, priority, status, department, submitted_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [g.case_code, g.title, g.description, g.category, g.priority, g.status, g.department, submitterId, createdAt]
      );
      const grievanceId = result.insertId;
      for (const t of g.timeline) {
        await pool.query(
          'INSERT INTO grievance_timeline (grievance_id, event_text, created_at) VALUES (?, ?, ?)',
          [grievanceId, t.text, daysAgoDate(t.daysAgo)]
        );
      }
    }
  }

  console.log('\nSeed complete. Demo accounts (all use the same password):');
  console.log(`  Password for every account: ${DEMO_PASSWORD}\n`);
  USERS.forEach(u => console.log(`  ${u.role.padEnd(8)} ${u.email}`));
  process.exit(0);
}

main().catch(err => {
  console.error('Seeding failed:', err.message);
  process.exit(1);
});
