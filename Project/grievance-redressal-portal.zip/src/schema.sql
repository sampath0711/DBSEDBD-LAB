-- Grievance Redressal Portal — MySQL schema
-- Run this once against an empty database (see README for setup steps).

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('student','faculty','staff','admin') NOT NULL,
  department    VARCHAR(120) NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  id                 INT AUTO_INCREMENT PRIMARY KEY,
  name               VARCHAR(80) NOT NULL UNIQUE,
  default_department VARCHAR(120) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grievances (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  case_code     VARCHAR(20) NOT NULL UNIQUE,        -- e.g. GRC-108
  title         VARCHAR(200) NOT NULL,
  description   TEXT NOT NULL,
  category      VARCHAR(80) NOT NULL,
  priority      ENUM('Routine','High','Urgent') NOT NULL DEFAULT 'Routine',
  status        ENUM('Submitted','Under Review','In Progress','Resolved','Closed') NOT NULL DEFAULT 'Submitted',
  department    VARCHAR(120) NOT NULL,
  submitted_by  INT NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (submitted_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grievance_timeline (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  grievance_id  INT NOT NULL,
  event_text    VARCHAR(500) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (grievance_id) REFERENCES grievances(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_grievances_status ON grievances(status);
CREATE INDEX idx_grievances_category ON grievances(category);
CREATE INDEX idx_grievances_submitted_by ON grievances(submitted_by);
CREATE INDEX idx_timeline_grievance ON grievance_timeline(grievance_id);
