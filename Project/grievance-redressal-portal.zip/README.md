# Grievance Redressal Portal — Full Stack (Node.js + Express + MySQL)

A working implementation of the portal from the slide deck: React-style single-page
frontend, a Node/Express REST API, JWT authentication, and a MySQL database with
real persistence, role-based access, and automatic category → department routing.

## Stack

- **Frontend**: static HTML/CSS/JS (served by Express), talks to the API with `fetch`
- **Backend**: Node.js + Express
- **Database**: MySQL
- **Auth**: JWT, passwords hashed with bcrypt

## 1. Prerequisites

- Node.js 18+
- A running MySQL server (local install, Docker, or a managed instance)

## 2. Install dependencies

```bash
npm install
```

## 3. Configure the database connection

Copy the example env file and fill in your MySQL credentials:

```bash
cp .env.example .env
```

Edit `.env`:

```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=grievance_portal

JWT_SECRET=change_this_to_a_long_random_string
JWT_EXPIRES_IN=8h

PORT=3000
```

## 4. Create the database schema

This creates the `grievance_portal` database (if it doesn't exist) and applies
`src/schema.sql`:

```bash
npm run setup-db
```

## 5. Load demo data

Seeds five categories, six demo users (one per role, two students/two staff),
and six sample grievances with timelines:

```bash
npm run seed
```

This prints the demo accounts. **Every seeded account uses the password
`password123`**:

| Role  | Email |
|---|---|
| Student | ananya.rao@campus.edu |
| Student | karthik.nair@campus.edu |
| Faculty | ramesh.iyer@campus.edu |
| Staff | priya.menon@campus.edu (Registrar's Office) |
| Staff | divya.kumar@campus.edu (Hostel Administration) |
| Admin | admin@campus.edu |

## 6. Run the app

```bash
npm start
```

Open **http://localhost:3000** — you'll land on the role-selection page. Each
role tile opens a dedicated login page, prefilled with the matching demo email.

## How it's wired together

- **Login** (`POST /api/auth/login`) checks the email/password against the
  `users` table and returns a JWT containing the user's id, name, role, and
  department. The frontend stores this in `localStorage` and sends it as
  `Authorization: Bearer <token>` on every request.
- **Submitting a grievance** (`POST /api/grievances`) looks up the category's
  default department from the `categories` table, creates the case as
  `Submitted`, and writes the first two timeline entries automatically —
  mirroring the "automated categorization & routing" feature from the deck.
- **Viewing grievances** (`GET /api/grievances`) is scoped server-side:
  students/faculty only see cases they submitted; staff see cases routed to
  their department plus their own; admins see everything. Query params
  `?status=` and `?category=` filter the admin/staff table.
- **Updating a case** (`PATCH /api/grievances/:id`) is restricted to admins,
  or staff acting on cases in their own department, and appends an entry to
  `grievance_timeline` recording exactly what changed.

## Project structure

```
src/
  db.js               MySQL connection pool
  schema.sql           Table definitions
  setupDb.js           Creates the DB + applies schema.sql
  seed.js               Demo users, categories, grievances
  server.js             Express app entry point
  middleware/auth.js    JWT verification + role guard
  routes/auth.js        POST /api/auth/login
  routes/grievances.js  Grievance CRUD, stats, timeline
  routes/categories.js  Category → department lookup
public/
  index.html            Frontend (landing page, role logins, dashboard,
                         submit form, case docket, admin console)
```

## Notes for going further

- Passwords are bcrypt-hashed; there's no self-service signup yet — add a
  `POST /api/auth/register` route (with an admin approval step, most likely)
  if you need one.
- The database uses raw SQL via `mysql2/promise` rather than an ORM, so the
  schema in `schema.sql` is the single source of truth for table structure.
- CORS is wide open (`app.use(cors())`) since the frontend is served from the
  same Express app. Lock this down if you split frontend/backend hosting.
